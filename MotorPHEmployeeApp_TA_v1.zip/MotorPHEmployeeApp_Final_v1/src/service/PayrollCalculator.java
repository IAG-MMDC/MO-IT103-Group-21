/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.time.Duration;
import java.time.LocalTime;
import java.time.Month;
import java.time.YearMonth;
import java.util.List;
import model.Attendance;
import model.Employee;
import model.PayrollResult;

/**
 *
 * @author Home
 */
public class PayrollCalculator {
    
    public static final String FIRST_HALF = "1 - 15";
public static final String SECOND_HALF = "16 - End of Month";
public static final String WHOLE_MONTH = "Whole Month";

    private static final int MAX_WORKING_MINS = 540;
    private static final int LUNCH_BREAK_MINS = 60;
    private static final int MINS_PER_HOUR = 60;
    
    // Compute Hours Worked
    public double computeHoursWorked(LocalTime login, LocalTime logout) {

        LocalTime graceLimit = LocalTime.of(8, 10);
        LocalTime startTime = LocalTime.of(8, 0);
        LocalTime endTime = LocalTime.of(17, 0);
        
        // No overtime
        if (logout.isAfter(endTime)) {
            logout = endTime;
        }
        
        // Grace period
        if (!login.isAfter(graceLimit)) {
            login = startTime;
        }
        
        long lateMinutes
                = Math.max(0, Duration.between(startTime, login).toMinutes());

        long minutesWorked
                = Math.min(
                        Duration.between(login, logout).toMinutes(),
                        MAX_WORKING_MINS - lateMinutes
                );

        // Lunch deduction
        if (minutesWorked > 60) {
            minutesWorked -= LUNCH_BREAK_MINS;
        } else {
            minutesWorked = 0;
        }

        return (double) minutesWorked / MINS_PER_HOUR;
    }

    // Generate Payslip
    public String generatePayslip(
            Employee employee,
            List<Attendance> attendanceList,
            int year,
            int month,
            String payCoverageOption) {

        double totalHoursWorked = 0;

        for (Attendance attendance : attendanceList) {

            if (!matchesAttendance(
                    attendance,
                    employee,
                    year,
                    month,
                    payCoverageOption)) {
                continue;
            }

            totalHoursWorked += computeHoursWorked(
                    attendance.getLogIn(),
                    attendance.getLogOut());
        }

        if (totalHoursWorked == 0) {
            return "No attendance records found for selected pay period.";
        }

        double grossSalary = totalHoursWorked * employee.getHourlyRate();

        double sss = 0;
        double philHealth = 0;
        double pagIBIG = 0;
        double withholdingTax = 0;
        double totalDeductions = 0;
        double netSalary = grossSalary;

        // Compute monthly deductions
sss = Deductions.computeSSSContribution(grossSalary);
philHealth = Deductions.computePhilHealthContribution(grossSalary);
pagIBIG = Deductions.computePagIBIGContribution(grossSalary);

// Split deductions for semi-monthly payroll
if (FIRST_HALF.equals(payCoverageOption)
        || SECOND_HALF.equals(payCoverageOption)) {

    sss /= 2;
    philHealth /= 2;
    pagIBIG /= 2;
}

// Compute total deductions
totalDeductions =
        Deductions.computeTotalDeductions(
                sss,
                pagIBIG,
                philHealth);

// Compute taxable income
double taxableIncome =
        Deductions.computeTaxableIncome(
                grossSalary,
                totalDeductions);

// Compute withholding tax
withholdingTax =
        Deductions.computeWithholdingTax(
                taxableIncome);

// Split tax for semi-monthly payroll
if (FIRST_HALF.equals(payCoverageOption)
        || SECOND_HALF.equals(payCoverageOption)) {

    withholdingTax /= 2;
}

// Compute net salary
netSalary =
        grossSalary
        - totalDeductions
        - withholdingTax;

        String payCoverageText
                = buildCoverageText(year, month, payCoverageOption);

        return formatPayslip(
                employee,
                payCoverageText,
                totalHoursWorked,
                grossSalary,
                sss,
                philHealth,
                pagIBIG,
                withholdingTax,
                totalDeductions,
                netSalary
        );
    }
    
    // Filter Attendance 
    private boolean matchesAttendance(
            Attendance attendance,
            Employee employee,
            int year,
            int month,
            String payCoverageOption) {
        
         // Match employee
        if (attendance.getEmpNo() != employee.getEmpNo()) {
            return false;
        }
        
        // Match year
        if (attendance.getDate().getYear() != year) {
            return false;
        }
        
        // Match month
        if (attendance.getDate().getMonthValue() != month) {
            return false;
        }

        int day = attendance.getDate().getDayOfMonth();
        
        // First cutoff
        if (FIRST_HALF.equals(payCoverageOption)) {
            return day <= 15;
        }
        // Second cutoff
        if (SECOND_HALF.equals(payCoverageOption)) {
            return day > 15;
        }
      
        return true;
    }
    
    // Coverage Text Builder
    private String buildCoverageText(
            int year,
            int month,
            String payCoverageOption) {

        Month monthName = Month.of(month);

        if (FIRST_HALF.equals(payCoverageOption)) {
            return monthName + " 1 - 15";
        }

        if (SECOND_HALF.equals(payCoverageOption)) {
            return monthName + " 16 - "
                    + YearMonth.of(year, month).lengthOfMonth();
        }

        return monthName + " 1 - " 
                + YearMonth.of(year, month).lengthOfMonth();
    }
    // Payslip Format
private String formatPayslip(
        Employee employee,
        String payCoverage,
        double hoursWorked,
        double grossSalary,
        double sss,
        double philHealth,
        double pagIBIG,
        double withholdingTax,
        double totalDeductions,
        double netSalary) {

    return String.format("""
========================================
          MOTORPH PAYSLIP
========================================

Employee Information
----------------------------------------
%-20s : %d
%-20s : %s %s
%-20s : %s

Payroll Period
----------------------------------------
%-20s : %s

Salary Information
----------------------------------------
%-20s : %.2f
%-20s : ₱%,.2f
%-20s : ₱%,.2f

Deductions
----------------------------------------
%-20s : ₱%,.2f
%-20s : ₱%,.2f
%-20s : ₱%,.2f
%-20s : ₱%,.2f
%-20s : ₱%,.2f

----------------------------------------
%-20s : ₱%,.2f
========================================
""",

            "Employee ID",
            employee.getEmpNo(),

            "Employee Name",
            employee.getFirstName(),
            employee.getLastName(),

            "Position",
            employee.getPosition(),

            "Pay Period",
            payCoverage,

            "Hours Worked",
            hoursWorked,

            "Hourly Rate",
            employee.getHourlyRate(),

            "Gross Salary",
            grossSalary,

            "SSS",
            sss,

            "PhilHealth",
            philHealth,

            "Pag-IBIG",
            pagIBIG,

            "Withholding Tax",
            withholdingTax,

            "Total Deductions",
            totalDeductions,

            "NET SALARY",
            netSalary
    );
}
    public PayrollResult calculatePayroll(
        Employee employee,
        List<Attendance> attendanceList,
        int year,
        int month,
        String payCoverageOption) {

    double totalHoursWorked = 0;

    for (Attendance attendance : attendanceList) {

        if (!matchesAttendance(
                attendance,
                employee,
                year,
                month,
                payCoverageOption)) {
            continue;
        }

        totalHoursWorked += computeHoursWorked(
                attendance.getLogIn(),
                attendance.getLogOut());
    }

    if (totalHoursWorked == 0) {
        return new PayrollResult(0, 0, 0);
    }

    double grossSalary =
            totalHoursWorked * employee.getHourlyRate();

    double sss =
            Deductions.computeSSSContribution(grossSalary);

    double philHealth =
            Deductions.computePhilHealthContribution(grossSalary);

    double pagIBIG =
            Deductions.computePagIBIGContribution(grossSalary);

    if (FIRST_HALF.equals(payCoverageOption)
            || SECOND_HALF.equals(payCoverageOption)) {

        sss /= 2;
        philHealth /= 2;
        pagIBIG /= 2;
    }

    double totalDeductions =
            Deductions.computeTotalDeductions(
                    sss,
                    pagIBIG,
                    philHealth);

    double taxableIncome =
            Deductions.computeTaxableIncome(
                    grossSalary,
                    totalDeductions);

    double withholdingTax =
            Deductions.computeWithholdingTax(
                    taxableIncome);

    if (FIRST_HALF.equals(payCoverageOption)
            || SECOND_HALF.equals(payCoverageOption)) {

        withholdingTax /= 2;
    }

    double netSalary =
            grossSalary
            - totalDeductions
            - withholdingTax;

    return new PayrollResult(
            grossSalary,
            totalDeductions + withholdingTax,
            netSalary);
}
}
