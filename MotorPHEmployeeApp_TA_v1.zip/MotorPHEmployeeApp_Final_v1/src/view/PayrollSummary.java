/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;

import service.PayrollCalculator;
import service.EmployeeDataHandler;
import service.AttendanceDataHandler;

import model.Employee;
import model.Attendance;
import model.PayrollResult;

import java.util.List;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JOptionPane;

public class PayrollSummary extends JPanel {
    private JLabel lblEmployeesValue;
private JLabel lblGrossValue;
private JLabel lblDeductionValue;
private JLabel lblAverageValue;

private JTextArea txtSummary;

private JComboBox<String> monthBox;
private JComboBox<Integer> yearBox;
private JComboBox<String> coverageBox;

private JButton btnExport;


    public PayrollSummary(MainGUIFrame mainGUIFrame) {

        setLayout(null);
        setBackground(Color.WHITE);
        
        // =====================================
// Page Title
// =====================================

JLabel lblTitle = new JLabel("Payroll Summary");

lblTitle.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                24));

lblTitle.setForeground(
        new Color(25,42,86));

lblTitle.setBounds(
        20,
        20,
        400,
        40);

add(lblTitle);

// =====================================
// Subtitle
// =====================================

JLabel lblSubtitle = new JLabel(
        "View payroll reports, salary summaries, and payroll statistics.");

lblSubtitle.setFont(
        new Font(
                "Segoe UI",
                Font.PLAIN,
                13));

lblSubtitle.setForeground(Color.GRAY);

lblSubtitle.setBounds(
        20,
        60,
        650,
        25);

add(lblSubtitle);

// =====================================
// Summary Information
// =====================================

JLabel lblSummary = new JLabel("Summary Information");

lblSummary.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                16));

lblSummary.setForeground(
        new Color(25,42,86));

lblSummary.setBounds(
        20,
        110,
        250,
        30);

add(lblSummary);

JLabel lblTotalEmployees =
        new JLabel("Total Employees:");

lblTotalEmployees.setBounds(20,150,180,25);
add(lblTotalEmployees);

JLabel lblGross =
        new JLabel("Total Gross Pay:");

lblGross.setBounds(20,185,180,25);
add(lblGross);

JLabel lblDeduction =
        new JLabel("Total Deductions:");

lblDeduction.setBounds(20,220,180,25);
add(lblDeduction);

JLabel lblAverage =
        new JLabel("Average Net Pay:");

lblAverage.setBounds(20,255,180,25);
add(lblAverage);

lblEmployeesValue = new JLabel("-");

lblEmployeesValue.setBounds(160,150,200,25);
add(lblEmployeesValue);

lblGrossValue = new JLabel("-");

lblGrossValue.setBounds(160,185,200,25);
add(lblGrossValue);

lblDeductionValue = new JLabel("-");

lblDeductionValue.setBounds(160,220,200,25);
add(lblDeductionValue);

lblAverageValue = new JLabel("-");

lblAverageValue.setBounds(160,255,200,25);
add(lblAverageValue);

// =====================================
// Payroll Options
// =====================================

JLabel lblOptions = new JLabel("Payroll Options");

lblOptions.setFont(
        new Font("Segoe UI", Font.BOLD, 16));

lblOptions.setForeground(
        new Color(25, 42, 86));

lblOptions.setBounds(
        420,
        110,
        200,
        30);

add(lblOptions);

JLabel lblMonth = new JLabel("Month:");

lblMonth.setBounds(
        420,
        150,
        70,
        25);

add(lblMonth);

String[] months = {
    "January","February","March","April",
    "May","June","July","August",
    "September","October","November","December"
};

monthBox = new JComboBox<>(months);

monthBox.setBounds(
        500,
        150,
        170,
        30);

monthBox.setSelectedIndex(5);

add(monthBox);

JLabel lblYear = new JLabel("Year:");

lblYear.setBounds(
        420,
        195,
        70,
        25);

add(lblYear);

yearBox = new JComboBox<>(
        new Integer[]{2024});

yearBox.setBounds(
        500,
        195,
        170,
        30);

add(yearBox);

JLabel lblCoverage = new JLabel("Pay Period:");

lblCoverage.setBounds(
        420,
        240,
        80,
        25);

add(lblCoverage);

coverageBox = new JComboBox<>(
        new String[]{
            PayrollCalculator.FIRST_HALF,
            PayrollCalculator.SECOND_HALF,
            PayrollCalculator.WHOLE_MONTH
        });

coverageBox.setBounds(
        500,
        240,
        170,
        30);

add(coverageBox);

// =====================================
// Summary Results
// =====================================

JLabel lblResults = new JLabel("Summary Results");

lblResults.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                16));

lblResults.setForeground(
        new Color(25,42,86));

lblResults.setBounds(
        20,
        295,
        250,
        30);

add(lblResults);

txtSummary = new JTextArea();

txtSummary.setEditable(false);
txtSummary.setLineWrap(true);
txtSummary.setWrapStyleWord(true);

txtSummary.setFont(
    new Font(
        "Monospaced",
        Font.PLAIN,
        13));

txtSummary.setText(
        "Payroll summary will be displayed here.\n\n"
      + "• Click Generate Summary.\n"
      + "• Review the payroll statistics.\n"
      + "• Export the summary to CSV if needed.");

JScrollPane scrollPane = new JScrollPane(txtSummary);

scrollPane.setBounds(
        20,
        335,
        760,
        280);

scrollPane.setBorder(
        BorderFactory.createTitledBorder(
                "Payroll Summary"));

add(scrollPane);

Color navy = new Color(25, 42, 86);

JButton btnGenerate = new JButton(
    "<html><center>"
    + "<b>Generate Summary</b><br>"
    + "<span style='font-size:9px;'>Calculate payroll totals</span>"
    + "</center></html>");

btnGenerate.setBounds(820, 360, 250, 70);

btnGenerate.setBackground(navy);
btnGenerate.setForeground(Color.WHITE);
btnGenerate.setFocusPainted(false);
btnGenerate.setBorderPainted(false);
btnGenerate.setOpaque(true);

btnGenerate.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                16));

add(btnGenerate);

btnGenerate.addActionListener(e -> generateSummary());

btnExport = new JButton(
    "<html><center>"
    + "<b>Export CSV</b><br>"
    + "<span style='font-size:9px;'>Export summary to CSV</span>"
    + "</center></html>");

btnExport.setBounds(820, 445, 250, 70);

btnExport.setBackground(navy);
btnExport.setForeground(Color.WHITE);
btnExport.setFocusPainted(false);
btnExport.setBorderPainted(false);
btnExport.setOpaque(true);

btnExport.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                16));

add(btnExport);

btnExport.setEnabled(false);

btnExport.addActionListener(e -> exportSummary());

JButton btnBack = new JButton("Back");

btnBack.setBounds(
        820,
        560,
        110,
        35);

add(btnBack);

JButton btnLogOut = new JButton("Log Out");

btnLogOut.setBounds(
        950,
        560,
        120,
        35);

add(btnLogOut);

btnBack.addActionListener(e ->
        mainGUIFrame.showCard("staffMenu-Card"));

btnLogOut.addActionListener(e ->
        mainGUIFrame.showCard("loginScreen-Card"));

        }

    private void generateSummary() {

    try {

        List<Employee> employees =
                EmployeeDataHandler.readEmployees();

        List<Attendance> attendanceList =
                AttendanceDataHandler.readAttendance();
        
        PayrollCalculator calculator = new PayrollCalculator();

int year =
        (Integer) yearBox.getSelectedItem();

int month =
        monthBox.getSelectedIndex() + 1;

String payPeriod =
        (String) coverageBox.getSelectedItem();

double totalGross = 0;
double totalDeductions = 0;
double totalNet = 0;

int employeeCount = 0;

for (Employee employee : employees) {

    PayrollResult result =
            calculator.calculatePayroll(
                    employee,
                    attendanceList,
                    year,
                    month,
                    payPeriod);

    if (result.getGrossSalary() == 0) {
        continue;
    }

    employeeCount++;

    totalGross += result.getGrossSalary();
    totalDeductions += result.getTotalDeductions();
    totalNet += result.getNetSalary();
}
double averageNet = 0;

if (employeeCount > 0) {
    averageNet = totalNet / employeeCount;
}

lblEmployeesValue.setText(String.valueOf(employeeCount));

lblGrossValue.setText(String.format("₱%,.2f", totalGross));

lblDeductionValue.setText(String.format("₱%,.2f", totalDeductions));

lblAverageValue.setText(String.format("₱%,.2f", averageNet));

txtSummary.setText(String.format(
    "========================================\n"
  + "        MOTORPH PAYROLL SUMMARY\n"
  + "========================================\n\n"

  + "Payroll Period\n"
  + "----------------------------------------\n"
  + "%-15s : %d\n"
  + "%-15s : %s\n"
  + "%-15s : %s\n\n"

  + "Payroll Statistics\n"
  + "----------------------------------------\n"
  + "%-15s : %d\n"
  + "%-15s : %s\n"
  + "%-15s : %s\n"
  + "%-15s : %s\n\n"

  + "Generated by MotorPH Employee App",

    "Year", year,
    "Month", monthBox.getSelectedItem(),
    "Pay Period", payPeriod,

    "Employees", employeeCount,
    "Gross Pay", String.format("₱%,.2f", totalGross),
    "Deductions", String.format("₱%,.2f", totalDeductions),
    "Average Net Pay", String.format("₱%,.2f", averageNet)
));
btnExport.setEnabled(true);

    } catch (Exception ex) {

        ex.printStackTrace();

    }
    
    }
    private void exportSummary() {
        
    if (lblEmployeesValue.getText().equals("-")) {

    JOptionPane.showMessageDialog(
            this,
            "Please generate the payroll summary first.",
            "No Summary Available",
            JOptionPane.WARNING_MESSAGE);

    return;
}

    try (BufferedWriter writer =
            new BufferedWriter(
                    new FileWriter("Payroll_Summary.csv"))) {

        writer.write("Metric,Value");
        writer.newLine();

        writer.write("Year," + yearBox.getSelectedItem());
        writer.newLine();

        writer.write("Month," + monthBox.getSelectedItem());
        writer.newLine();

        writer.write("Pay Period," + coverageBox.getSelectedItem());
        writer.newLine();

        writer.write("Total Employees," + lblEmployeesValue.getText());
        writer.newLine();

        writer.write("Total Gross Pay," + lblGrossValue.getText());
        writer.newLine();

        writer.write("Total Deductions," + lblDeductionValue.getText());
        writer.newLine();

        writer.write("Average Net Pay," + lblAverageValue.getText());
        writer.newLine();

        JOptionPane.showMessageDialog(
                this,
                "Payroll Summary exported successfully!\n\n"
                + "File saved as Payroll_Summary.csv");

    } catch (IOException ex) {

        JOptionPane.showMessageDialog(
                this,
                "Error exporting Payroll Summary.",
                "Export Error",
                JOptionPane.ERROR_MESSAGE);

        ex.printStackTrace();
    }
}

}