/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.Color;
import java.awt.Font;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.BorderFactory;

import model.Attendance;
import model.Employee;

import service.AttendanceDataHandler;
import service.PayrollCalculator;


/**
 *
 * @author Home
 */
public class EmployeeMenu extends JPanel {

    private JTextArea displayArea;
    private Employee employee;

    JComboBox coverageBox;
    JComboBox monthBox;
    JComboBox yearBox;

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    public EmployeeMenu(MainGUIFrame mainGUIFrame) {

        setLayout(null);
        setBackground(Color.WHITE);
        setOpaque(true);
        
        // Label
       JLabel lblTitle =
    new JLabel("Employee Dashboard");
       lblTitle.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                24));
        lblTitle.setForeground(
        new Color(25, 42, 86));
        lblTitle.setBounds(
        20,
        20,
        400,
        40);
        add(lblTitle);
        
        JLabel lblSubtitle = new JLabel(
        "View your personal information and payslip.");

lblSubtitle.setFont(
        new Font(
                "Segoe UI",
                Font.PLAIN,
                13));

lblSubtitle.setForeground(Color.GRAY);

lblSubtitle.setBounds(
        20,
        60,
        450,
        25);

add(lblSubtitle);

JLabel lblOptions = new JLabel("Payroll Options");

lblOptions.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                16));

lblOptions.setForeground(
        new Color(25, 42, 86));

lblOptions.setBounds(
        480,
        100,
        220,
        30);

add(lblOptions);
        
        JLabel lblMonth = new JLabel("Month:");
        lblMonth.setBounds(480, 140, 70, 25);
        add(lblMonth);

        JLabel lblYear = new JLabel("Year:");
        lblYear.setBounds(480, 195, 70, 25);
        add(lblYear);
        
        JLabel lblPayCov = new JLabel("Pay Period:");
lblPayCov.setBounds(480, 250, 90, 25);
        add(lblPayCov);

        // Buttons
        JButton btnViewED = new JButton("View Details");
        Color navy = new Color(25, 42, 86);
        btnViewED.setBackground(navy);
btnViewED.setForeground(Color.WHITE);
btnViewED.setFocusPainted(false);
btnViewED.setBorderPainted(false);
btnViewED.setOpaque(true);

btnViewED.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                14));
        btnViewED.setBounds(500, 330, 190, 60);
        add(btnViewED);

        JButton btnViewPS = new JButton("View Payslip");
        btnViewPS.setBounds(500, 405, 190, 60);
        add(btnViewPS);
        btnViewPS.setBackground(navy);
btnViewPS.setForeground(Color.WHITE);
btnViewPS.setFocusPainted(false);
btnViewPS.setBorderPainted(false);
btnViewPS.setOpaque(true);

btnViewPS.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                14));

        JButton btnLogOut = new JButton("Logout");
        btnLogOut.setBounds(500, 505, 110, 25);
        add(btnLogOut);

        // Arrays
        String[] months = {
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
};
        
        monthBox = new JComboBox(months);
monthBox.setSelectedItem("June");

        Integer[] years = {2024, 2025, 2026};
        String[] coverageOptions = {"1 - 15", "16 - 30/31", "1 - 30/31"};

        // Combo Box
        monthBox = new JComboBox(months);
        monthBox.setBounds(590, 141, 170, 30);
        
        monthBox.setSelectedItem("June");
     
        add(monthBox);

        yearBox = new JComboBox(years);
        yearBox.setBounds(590, 191, 170, 30);
        add(yearBox);

        coverageBox = new JComboBox(coverageOptions);
        coverageBox.setBounds(590, 241, 170, 30);
        add(coverageBox);

        //Button Actions
        btnViewED.addActionListener(e -> showDetails());
        btnViewPS.addActionListener(e -> showPayslip());
        btnLogOut.addActionListener(e -> mainGUIFrame.showCard("loginScreen-Card"));

        // Display Area
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        // Scroll Pane
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBounds(
        20,
        140,
        430,
        390);
        add(scrollPane);

        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        
        JLabel lblInfo = new JLabel("Employee Information");

lblInfo.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                16));

lblInfo.setForeground(
        new Color(25, 42, 86));

lblInfo.setBounds(
        20,
        100,
        250,
        30);

add(lblInfo);

scrollPane.setBorder(
        BorderFactory.createTitledBorder(
                "Employee Information"));

    }

    // Set Employee
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    // Show Employee Details
    private void showDetails() {
        if (employee == null) {
            return;
        }

displayArea.setText(
    String.format(
        """
========================================
          EMPLOYEE PROFILE
========================================

Personal Information
----------------------------------------
%-25s %s
%-25s %s
%-25s %s
%-25s %s

----------------------------------------
Contact Information
----------------------------------------
%-25s %s
%-25s %s

----------------------------------------
Government Information
----------------------------------------
%-25s %s
%-25s %s
%-25s %s
%-25s %s

----------------------------------------
Employment Information
----------------------------------------
%-25s %s
%-25s %s
%-25s %s

----------------------------------------
Salary Information
----------------------------------------
%-25s ₱%,.2f
%-25s ₱%,.2f
%-25s ₱%,.2f
%-25s ₱%,.2f
%-25s ₱%,.2f
%-25s ₱%,.2f
========================================
""",

        "Employee ID:", employee.getEmpNo(),
        "Last Name:", employee.getLastName(),
        "First Name:", employee.getFirstName(),
        "Birthday:", employee.getBirthday().format(DATE_FORMAT),

        "Address:",
        employee.getAddress().length() > 30
                ? employee.getAddress().substring(0, 35) + "..."
                : employee.getAddress(),

        "Phone #:", employee.getPhoneNumber(),

        "SSS #:", employee.getSSSNumber(),
        "PhilHealth #:", employee.getPhilHealthNumber(),
        "TIN #:", employee.getTINNumber(),
        "PagIBIG #:", employee.getPagIBIGNumber(),

        "Status:", employee.getStatus(),
        "Position:", employee.getPosition(),
        "Immediate Supervisor:", employee.getImmediateSupervisor(),

        "Basic Salary:", (double) employee.getBasicSalary(),
"Rice Subsidy:", (double) employee.getRiceSubsidy(),
"Phone Allowance:", (double) employee.getPhoneAllowance(),
"Clothing Allowance:", (double) employee.getClothingAllowance(),
"Gross Semi-Monthly Rate:", (double) employee.getGrossSemiMonthlyRate(),
"Hourly Rate:", employee.getHourlyRate()
    )
    + "\nGenerated by MotorPH Employee App"
);
    }

    private void showPayslip() {
        if (employee == null) {
            return;
        }

        List<Attendance> attendanceList
                = AttendanceDataHandler.readAttendance();

        String monthName = (String) monthBox.getSelectedItem();

int month = switch (monthName) {
    case "January" -> 1;
    case "February" -> 2;
    case "March" -> 3;
    case "April" -> 4;
    case "May" -> 5;
    case "June" -> 6;
    case "July" -> 7;
    case "August" -> 8;
    case "September" -> 9;
    case "October" -> 10;
    case "November" -> 11;
    case "December" -> 12;
    default -> 1;
};
        int year = (Integer) yearBox.getSelectedItem();
        String coverage = (String) coverageBox.getSelectedItem();

        PayrollCalculator calculator = new PayrollCalculator();

        String payslip = calculator.generatePayslip(
                employee,
                attendanceList,
                year,
                month,
                coverage
        );

        displayArea.setText(payslip);
    }
}
