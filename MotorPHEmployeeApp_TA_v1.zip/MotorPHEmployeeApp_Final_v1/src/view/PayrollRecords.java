/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.Color;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import model.Attendance;
import model.Employee;
import service.AttendanceDataHandler;
import service.EmployeeDataHandler;
import service.PayrollCalculator;
import java.io.IOException;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.BorderFactory;

/**
 *
 * @author Home
 */
public class PayrollRecords extends JPanel {

    private JTextField txtSearchNo, txtSearchName;
    private JTextArea displayArea;
    private Employee selectedEmployee = null;
    
    private JLabel lblSelectedTitle;
private JLabel lblSelectedEmpNo;
private JLabel lblSelectedEmpName;

    private JComboBox monthBox, coverageBox, yearBox;
    

    public PayrollRecords(MainGUIFrame mainGUIFrame) {

setLayout(null);
setBackground(Color.WHITE);
setOpaque(true);

// =====================================
// Page Title
// =====================================

JLabel lblTitle = new JLabel("Payroll Processing");

lblTitle.setFont(
        new Font("Segoe UI",
        Font.BOLD,
        24));

lblTitle.setForeground(
        new Color(25, 42, 86));

lblTitle.setBounds(20, 20, 450, 40);

add(lblTitle);

// =====================================
// Subtitle
// =====================================

JLabel lblSubtitle =
        new JLabel(
        "Generate payroll for employees, process salaries, and save payroll records.");

lblSubtitle.setFont(
        new Font("Segoe UI",
        Font.PLAIN,
        13));

lblSubtitle.setForeground(Color.GRAY);

lblSubtitle.setBounds(20, 60, 650, 25);

add(lblSubtitle);

// =====================================
// Employee Search
// =====================================

JLabel lblSearchTitle = new JLabel("Employee Search");

lblSearchTitle.setFont(
        new Font("Segoe UI",
        Font.BOLD,
        16));

lblSearchTitle.setForeground(
        new Color(25,42,86));

lblSearchTitle.setBounds(
        20,
        100,
        250,
        30);

add(lblSearchTitle);

// =====================================
// Payroll Options
// =====================================

JLabel lblOptions = new JLabel("Payroll Options");

lblOptions.setFont(
        new Font("Segoe UI",
        Font.BOLD,
        16));

lblOptions.setForeground(
        new Color(25,42,86));

lblOptions.setBounds(
        20,
        260,
        250,
        30);

add(lblOptions);

// =====================================
// Payroll Results
// =====================================

JLabel lblResults = new JLabel("Payroll Results");

lblResults.setFont(
        new Font("Segoe UI",
        Font.BOLD,
        16));

lblResults.setForeground(
        new Color(25,42,86));

lblResults.setBounds(
        20,
        340,
        250,
        30);

add(lblResults);


        //Labels and Text Fields
        JLabel lblSearchNo = new JLabel("Employee #:");
        lblSearchNo.setBounds(20, 140, 140, 25);
        add(lblSearchNo);

        txtSearchNo = new JTextField();
        txtSearchNo.setBounds(170, 140, 250, 30);
        add(txtSearchNo);

        JLabel lblSearchName = new JLabel("Employee Name:");
        lblSearchName.setBounds(20, 180, 140, 25);
        add(lblSearchName);

        txtSearchName = new JTextField();
        txtSearchName.setBounds(170, 180, 250, 30);
        add(txtSearchName);
        
        // =====================================
// Selected Employee
// =====================================

lblSelectedTitle = new JLabel("Selected Employee");

lblSelectedTitle.setForeground(
        new Color(25, 42, 86));

lblSelectedTitle.setFont(
        new Font("Segoe UI",
        Font.BOLD,
        13));

lblSelectedTitle.setBounds(20, 215, 150, 20);
add(lblSelectedTitle);

lblSelectedEmpNo = new JLabel("Employee #: -");
lblSelectedEmpNo.setBounds(170, 215, 250, 20);
add(lblSelectedEmpNo);

lblSelectedEmpName = new JLabel("Name: -");
lblSelectedEmpName.setBounds(170, 235, 300, 20);
add(lblSelectedEmpName);
        
        JLabel lblMonth = new JLabel("Month:");
        lblMonth.setBounds(20, 300, 70, 25);
        add(lblMonth);

        JLabel lblYear = new JLabel("Year:");
        lblYear.setBounds(320, 300, 50, 25);
        add(lblYear);
        
        JLabel lblPayCov = new JLabel("Pay Period:");
        lblPayCov.setBounds(540, 300, 100, 25);
        add(lblPayCov);

        //Buttons
        JButton btnSubmitNo = new JButton("Search");
        btnSubmitNo.setBounds(435, 140, 110, 30);
        add(btnSubmitNo);
        btnSubmitNo.setFocusPainted(false);

btnSubmitNo.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                12));


        JButton btnSubmitName = new JButton("Search");
        btnSubmitName.setBounds(435, 180, 110, 30);
        add(btnSubmitName); 
        btnSubmitName.setFocusPainted(false);

btnSubmitName.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                12));
        
        Color navy = new Color(25, 42, 86);
        
        JButton btnCalculateOne = new JButton(
    "<html><center>"
    + "<b>Process One</b><br>"
    + "<span style='font-size:9px;'>Calculate payroll for one employee</span>"
    + "</center></html>"
);
        btnCalculateOne.setBackground(navy);
btnCalculateOne.setForeground(Color.WHITE);

btnCalculateOne.setFocusPainted(false);
btnCalculateOne.setBorderPainted(false);
btnCalculateOne.setOpaque(true);

btnCalculateOne.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                16));

        btnCalculateOne.setBounds(820, 380, 250, 70);
        add(btnCalculateOne);
        btnCalculateOne.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnCalculateAll = new JButton(
    "<html><center>"
    + "<b>Process All</b><br>"
    + "<span style='font-size:9px;'>Calculate payroll for all employees</span>"
    + "</center></html>"
);
        
        btnCalculateAll.setBackground(navy);
btnCalculateAll.setForeground(Color.WHITE);

btnCalculateAll.setFocusPainted(false);
btnCalculateAll.setBorderPainted(false);
btnCalculateAll.setOpaque(true);

btnCalculateAll.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                16));

        btnCalculateAll.setBounds(820, 465, 250, 70);
        add(btnCalculateAll);
        btnCalculateAll.setFont(new Font("Segoe UI", Font.BOLD, 16));
        
        JButton btnSave = new JButton(
    "<html><center>"
    + "<b>Save Payroll</b><br>"
    + "<span style='font-size:9px;'>Save payroll records to file</span>"
    + "</center></html>"
);
        btnSave.setBackground(navy);
btnSave.setForeground(Color.WHITE);

btnSave.setFocusPainted(false);
btnSave.setBorderPainted(false);
btnSave.setOpaque(true);

btnSave.setFont(
        new Font(
                "Segoe UI",
                Font.BOLD,
                16));

        btnSave.setBounds(820, 550, 250, 70);
        add(btnSave);
        btnSave.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(820, 650, 110, 35);
        add(btnBack);

        JButton btnLogOut = new JButton("Log Out");
        btnLogOut.setBounds(950, 650, 120, 35);
        add(btnLogOut);

        //Display Area
        displayArea = new JTextArea();
        displayArea.setEditable(false);
        displayArea.setLineWrap(true);
displayArea.setWrapStyleWord(true);
displayArea.setCaretPosition(0);
        displayArea.setFont(
        new Font(
                "Segoe UI",
                Font.PLAIN,
                13));
        

displayArea.setText(
        "Payroll results will be displayed here.\n\n"
        + "• Search for an employee.\n"
        + "• Select the payroll options.\n"
        + "• Click Process One or Process All.");

        // Arrays
        String[] months = {
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
};
        Integer[] years = {2024, 2025, 2026};
       String[] coverageOptions = {
    PayrollCalculator.FIRST_HALF,
    PayrollCalculator.SECOND_HALF,
    PayrollCalculator.WHOLE_MONTH
};

        // JCombo Box
        monthBox = new JComboBox(months);
        monthBox.setBounds(110, 300, 180, 30);
        add(monthBox);
        monthBox.setSelectedItem("June");

        yearBox = new JComboBox(years);
        yearBox.setBounds(380, 300, 120, 30);
        add(yearBox);

        coverageBox = new JComboBox(coverageOptions);
        coverageBox.setBounds(650, 300, 180, 30);
        add(coverageBox);

        // JScroll Pane
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBorder(
        BorderFactory.createTitledBorder(
                "Generated Payroll"));
        scrollPane.setBounds(20, 380, 760, 250);
        add(scrollPane);

        // Horizontal And Vertical Scroll
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        // Button Actions 
        btnSubmitNo.addActionListener(e -> submitNo());
        btnSubmitName.addActionListener(e -> submitName());

        btnCalculateOne.addActionListener(e -> calculateOneEmployee());
        btnCalculateAll.addActionListener(e -> calculateAllEmployees());
        btnSave.addActionListener(e -> savePayroll());

        btnBack.addActionListener(e -> mainGUIFrame.showCard("staffMenu-Card"));
        btnLogOut.addActionListener(e -> mainGUIFrame.showCard("loginScreen-Card"));
    }

    // Submit Number 
    private void submitNo() {
        
        clearSelectedEmployee();

        String input = txtSearchNo.getText().trim();

        if (input.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter employee number.",
                    "ERROR",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        try {
            int empNo = Integer.parseInt(input);

            selectedEmployee = EmployeeDataHandler.findEmpNo(empNo);

            if (selectedEmployee == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Employee not found.",
                        "ERROR",
                        JOptionPane.ERROR_MESSAGE
                );
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Invalid employee number format.",
                    "ERROR",
                    JOptionPane.ERROR_MESSAGE
            );
        }
        
        lblSelectedTitle.setText("✓ Selected Employee");
        
        lblSelectedEmpNo.setText(
        "Employee #: " + selectedEmployee.getEmpNo());

lblSelectedEmpName.setText(
        "Employee Name: "
        + selectedEmployee.getFirstName()
        + " "
        + selectedEmployee.getLastName());

        clearFields();
    }

    // Submit Name
    private void submitName() {

        clearSelectedEmployee();
        
        String input = txtSearchName.getText().trim();

        if (input.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter employee name.",
                    "ERROR",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        List<Employee> employees = EmployeeDataHandler.readEmployees();

        selectedEmployee = null;

        for (Employee e : employees) {

            String fullName = e.getFirstName() + " " + e.getLastName();

            if (fullName.equalsIgnoreCase(input)) {
                selectedEmployee = e;
                break;
            }
        }

        if (selectedEmployee == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Employee not found.",
                    "ERROR",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }
        lblSelectedTitle.setText("✓ Selected Employee");
        
        lblSelectedEmpNo.setText(
        "Employee #: " + selectedEmployee.getEmpNo());

lblSelectedEmpName.setText(
        "Employee Name: "
        + selectedEmployee.getFirstName()
        + " "
        + selectedEmployee.getLastName());

        clearFields();
    }
    
    // Calculate One Employee
    private void calculateOneEmployee() {

        if (selectedEmployee == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter employee # or name first.",
                    "MESSAGE",
                    JOptionPane.INFORMATION_MESSAGE
            );
            return;
        }

        List<Attendance> attendanceList
                = AttendanceDataHandler.readAttendance();

        int month = monthBox.getSelectedIndex() + 1;
        int year = (Integer) yearBox.getSelectedItem();
        String coverage = (String) coverageBox.getSelectedItem();

        PayrollCalculator calculator = new PayrollCalculator();

        String payslip = calculator.generatePayslip(
                selectedEmployee,
                attendanceList,
                year,
                month,
                coverage
        );

        displayArea.setText(payslip);
        displayArea.setCaretPosition(0);
    }

    // Calculate All Employees
    private void calculateAllEmployees() {

        List<Employee> employees = EmployeeDataHandler.readEmployees();
        List<Attendance> attendanceList = AttendanceDataHandler.readAttendance();

        if (employees.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "No employees found.",
                    "MESSAGE",
                    JOptionPane.INFORMATION_MESSAGE
            );
            return;
        }

        int month = monthBox.getSelectedIndex() + 1;
        int year = (Integer) yearBox.getSelectedItem();
        String coverage = (String) coverageBox.getSelectedItem();

        PayrollCalculator calculator = new PayrollCalculator();

        StringBuilder sb = new StringBuilder();
        sb.append("ALL PAYSLIPS\n\n");

        for (Employee emp : employees) {

            String payslip = calculator.generatePayslip(
                    emp,
                    attendanceList,
                    year,
                    month,
                    coverage
            );

            sb.append("========================================\n");
            sb.append(payslip).append("\n\n");
        }

        displayArea.setText(sb.toString());
        displayArea.setCaretPosition(0);
    }
    
    // Save Payroll
    private void savePayroll() {
        String content = displayArea.getText();

        if (content.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "No payroll information to save.",
                    "MESSAGE",
                    JOptionPane.INFORMATION_MESSAGE
            );
            return;
        }

        try {
            Files.writeString(Path.of("payroll_output.txt"), content);
            JOptionPane.showMessageDialog(
                    this,
                    "Payroll has been saved successfully.",
                    "MESSAGE",
                    JOptionPane.INFORMATION_MESSAGE
            );
        } catch (IOException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Unable to save payroll information.",
                    "MESSAGE",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private void clearFields() {
        txtSearchNo.setText("");
        txtSearchName.setText("");
    }
    private void clearSelectedEmployee() {

    selectedEmployee = null;
    
    lblSelectedTitle.setText("Selected Employee");

    lblSelectedEmpNo.setText("Employee #: -");
    lblSelectedEmpName.setText("Employee Name: -");
}
}
