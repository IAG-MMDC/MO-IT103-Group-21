/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Home
 */

// UPDATED CODE
public class PayrollRecord {

    private int empNo;
    private int year;
    private int month;
    private String payCoverage;

    private double hoursWorked;
    private double grossPay;

    private double sss;
    private double philHealth;
    private double pagIBIG;
    private double withholdingTax;

    private double totalDeductions;
    private double netPay;

    public PayrollRecord(
            int empNo,
            int year,
            int month,
            String payCoverage,
            double hoursWorked,
            double grossPay,
            double sss,
            double philHealth,
            double pagIBIG,
            double withholdingTax,
            double totalDeductions,
            double netPay
    ) {

        this.empNo = empNo;
        this.year = year;
        this.month = month;
        this.payCoverage = payCoverage;

        this.hoursWorked = hoursWorked;
        this.grossPay = grossPay;

        this.sss = sss;
        this.philHealth = philHealth;
        this.pagIBIG = pagIBIG;
        this.withholdingTax = withholdingTax;

        this.totalDeductions = totalDeductions;
        this.netPay = netPay;
    }

    public int getEmpNo() {
        return empNo;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public String getPayCoverage() {
        return payCoverage;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public double getGrossPay() {
        return grossPay;
    }

    public double getSSS() {
        return sss;
    }

    public double getPhilHealth() {
        return philHealth;
    }

    public double getPagIBIG() {
        return pagIBIG;
    }

    public double getWithholdingTax() {
        return withholdingTax;
    }

    public double getTotalDeductions() {
        return totalDeductions;
    }

    public double getNetPay() { return netPay;}
   
}
