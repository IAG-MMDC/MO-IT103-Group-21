/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Home
 */

// UPDATED
public class PayrollSummary {


    private int totalEmployees;
    private double totalGrossPay;
    private double totalDeductions;
    private double averageNetPay;


    public PayrollSummary(

            int totalEmployees,
            double totalGrossPay,
            double totalDeductions,
            double averageNetPay

    ){

        this.totalEmployees = totalEmployees;
        this.totalGrossPay = totalGrossPay;
        this.totalDeductions = totalDeductions;
        this.averageNetPay = averageNetPay;

    }

    // Getter Methods
    public int getTotalEmployees(){return totalEmployees;}
    public double getTotalGrossPay(){return totalGrossPay;}
    public double getTotalDeductions(){return totalDeductions;}
    public double getAverageNetPay(){return averageNetPay;}
}
