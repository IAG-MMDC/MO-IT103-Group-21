/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;

import service.PayrollCalculator;
import service.EmployeeDataHandler;
import service.AttendanceDataHandler;

import model.Employee;
import model.Attendance;

import java.util.List;

import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import model.PayrollRecord;
import model.PayrollSummary;
import service.Formatter;
import service.PayrollDataHandler;

public class PayrollSummaryGUI extends JPanel {

    // Labels
    private JLabel lblEmployeesValue;
    private JLabel lblGrossValue;
    private JLabel lblDeductionValue;
    private JLabel lblAverageValue;
    
    // Buttons
    private JButton btnGenerate;
    private JButton btnExport;
    private JButton btnBack;
    private JButton btnLogOut;

    // Display
    private JTextArea txtSummary;

    // Payroll Options
    private JComboBox<String> monthBox;
    private JComboBox<Integer> yearBox;
    private JComboBox<String> coverageBox;

    // Data
    private PayrollSummary generatedSummary;

    public PayrollSummaryGUI(MainGUIFrame mainGUIFrame) {

        setLayout(null);
        setBackground(Color.WHITE);

        createTitle();

        createSummaryInfo();

        createPayrollOptions();

        createSummaryDisplay();

        createButtons();

        setupButtonActions(mainGUIFrame);
    }
    
    // Title 
    private void createTitle() {

        JLabel lblTitle = new JLabel("Payroll Summary");

        lblTitle.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        24));

        lblTitle.setForeground(
                new Color(25, 42, 86));

        lblTitle.setBounds(
                20,
                20,
                400,
                40);

        add(lblTitle);

        JLabel lblSubtitle = new JLabel(
                "View payroll reports, salary summaries, and payroll statistics.");

        lblSubtitle.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        13));

        lblSubtitle.setForeground(Color.GRAY);

        lblSubtitle.setBounds(
                20,
                60,
                650,
                25);

        add(lblSubtitle);
    }
    
    // Summary Information
    private void createSummaryInfo() {

        JLabel lblSummary = new JLabel("Summary Information");
        lblSummary.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblSummary.setForeground(new Color(25, 42, 86));

        lblSummary.setBounds(
                20,
                110,
                250,
                30);

        add(lblSummary);

        JLabel lblTotalEmployees
                = new JLabel("Total Employees:");

        lblTotalEmployees.setBounds(20, 150, 180, 25);
        add(lblTotalEmployees);

        JLabel lblGross
                = new JLabel("Total Gross Pay:");

        lblGross.setBounds(20, 185, 180, 25);
        add(lblGross);

        JLabel lblDeduction
                = new JLabel("Total Deductions:");

        lblDeduction.setBounds(20, 220, 180, 25);
        add(lblDeduction);

        JLabel lblAverage
                = new JLabel("Average Net Pay:");

        lblAverage.setBounds(20, 255, 180, 25);
        add(lblAverage);

        lblEmployeesValue = new JLabel("-");
        lblEmployeesValue.setBounds(160, 150, 200, 25);
        add(lblEmployeesValue);

        lblGrossValue = new JLabel("-");
        lblGrossValue.setBounds(160, 185, 200, 25);
        add(lblGrossValue);

        lblDeductionValue = new JLabel("-");
        lblDeductionValue.setBounds(160, 220, 200, 25);
        add(lblDeductionValue);

        lblAverageValue = new JLabel("-");
        lblAverageValue.setBounds(160, 255, 200, 25);
        add(lblAverageValue);
    }
    // Payroll Options
    private void createPayrollOptions() {

        JLabel lblOptions = new JLabel("Payroll Options");
        lblOptions.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblOptions.setForeground(new Color(25, 42, 86));

        lblOptions.setBounds(
                420,
                110,
                200,
                30);

        add(lblOptions);

        JLabel lblMonth = new JLabel("Month:");
        lblMonth.setBounds(420, 150, 70, 25);
        add(lblMonth);

        monthBox = new JComboBox<>(new String[]{
            "January", "February", "March", "April",
            "May", "June", "July", "August",
            "September", "October", "November", "December"
        });

        monthBox.setBounds(500, 150, 170, 30);
        monthBox.setSelectedIndex(5);
        add(monthBox);

        JLabel lblYear = new JLabel("Year:");
        lblYear.setBounds(420, 195, 70, 25);
        add(lblYear);

        yearBox = new JComboBox<>(new Integer[]{2024});
        yearBox.setBounds(500, 195, 170, 30);
        add(yearBox);

        JLabel lblCoverage = new JLabel("Pay Period:");
        lblCoverage.setBounds(420, 240, 80, 25);
        add(lblCoverage);

        coverageBox = new JComboBox<>(new String[]{
            PayrollCalculator.FIRST_HALF,
            PayrollCalculator.SECOND_HALF,
            PayrollCalculator.WHOLE_MONTH
        });

        coverageBox.setBounds(500, 240, 170, 30);
        add(coverageBox);
    }
    
    // Summary Display
    private void createSummaryDisplay() {

        JLabel lblResults = new JLabel("Summary Results");
        lblResults.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblResults.setForeground(new Color(25, 42, 86));

        lblResults.setBounds(
                20,
                295,
                250,
                30);

        add(lblResults);

        txtSummary = new JTextArea();

        txtSummary.setEditable(false);
        txtSummary.setLineWrap(true);
        txtSummary.setWrapStyleWord(true);

        txtSummary.setFont(
                new Font(
                        "Monospaced",
                        Font.PLAIN,
                        13));

        txtSummary.setText("""
            Payroll summary will be displayed here.

            • Click Generate Summary.
            • Review the payroll statistics.
            • Export the summary to CSV if needed.
            """);

        JScrollPane scrollPane = new JScrollPane(txtSummary);

        scrollPane.setBounds(
                20,
                335,
                760,
                280);

        scrollPane.setBorder(
                BorderFactory.createTitledBorder("Payroll Summary"));

        add(scrollPane);
    }
    
    // Buttons 
    private void createButtons() {

        Color navy = new Color(25, 42, 86);

        // Generate Summary Button
        btnGenerate = new JButton(
                "<html><center>"
                + "<b>Generate Summary</b><br>"
                + "<span style='font-size:9px;'>Calculate payroll totals</span>"
                + "</center></html>");

        btnGenerate.setBounds(820, 360, 250, 70);

        btnGenerate.setBackground(navy);
        btnGenerate.setForeground(Color.WHITE);
        btnGenerate.setFocusPainted(false);
        btnGenerate.setBorderPainted(false);
        btnGenerate.setOpaque(true);

        btnGenerate.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        16));

        add(btnGenerate);

        // Export Button
        btnExport = new JButton(
                "<html><center>"
                + "<b>Export CSV</b><br>"
                + "<span style='font-size:9px;'>Export summary to CSV</span>"
                + "</center></html>");

        btnExport.setBounds(820, 445, 250, 70);

        btnExport.setBackground(navy);
        btnExport.setForeground(Color.WHITE);
        btnExport.setFocusPainted(false);
        btnExport.setBorderPainted(false);
        btnExport.setOpaque(true);

        btnExport.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        16));

        btnExport.setEnabled(false);

        add(btnExport);

        // Back button
        btnBack = new JButton("Back");

        btnBack.setBounds(
                820,
                560,
                110,
                35);

        add(btnBack);

        // Log out Button
        btnLogOut = new JButton("Log Out");

        btnLogOut.setBounds(
                950,
                560,
                120,
                35);

        add(btnLogOut);
    }

    private void setupButtonActions(MainGUIFrame mainGUIFrame) {

        btnGenerate.addActionListener(e -> generateSummary());

        btnExport.addActionListener(e -> exportSummary());

        btnBack.addActionListener(
                e -> mainGUIFrame.showCard("staffMenu-Card"));

        btnLogOut.addActionListener(
                e -> mainGUIFrame.showCard("loginScreen-Card"));
    }

    private int getSelectedYear() {
        return (Integer) yearBox.getSelectedItem();
    }

    private int getSelectedMonth() {
        return monthBox.getSelectedIndex() + 1;
    }

    private String getSelectedCoverage() {
        return (String) coverageBox.getSelectedItem();
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Error",
                JOptionPane.ERROR_MESSAGE);
    }

    private void showInfo(String message) {
        JOptionPane.showMessageDialog(
                this,
                message,
                "Information",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private void updateSummaryLabels(
            int employees,
            double gross,
            double deductions,
            double averageNet) {

        lblEmployeesValue.setText(
                String.valueOf(employees)
        );

        lblGrossValue.setText(
                String.format("₱%,.2f", gross)
        );

        lblDeductionValue.setText(
                String.format("₱%,.2f", deductions)
        );

        lblAverageValue.setText(
                String.format("₱%,.2f", averageNet)
        );
    }

    // Generate Payroll Summary
    private void generateSummary() {

        try {

            List<Employee> employees
                    = EmployeeDataHandler.readEmployees();

            List<Attendance> attendanceList
                    = AttendanceDataHandler.readAttendance();

            PayrollCalculator calculator
                    = new PayrollCalculator();

            List<PayrollRecord> payrollRecords
                    = new ArrayList<>();

            // Generate payroll for every employee
            for (Employee employee : employees) {

                PayrollRecord record
                        = calculator.computePayroll(
                                employee,
                                attendanceList,
                                getSelectedYear(),
                                getSelectedMonth(),
                                getSelectedCoverage()
                        );

                if (record != null) {

                    payrollRecords.add(record);

                }

            }

            // Calculate summary totals
            generatedSummary
                    = calculator.calculateTotals(
                            payrollRecords
                    );

            // Update summary labels
            updateSummaryLabels(
                    generatedSummary.getTotalEmployees(),
                    generatedSummary.getTotalGrossPay(),
                    generatedSummary.getTotalDeductions(),
                    generatedSummary.getAverageNetPay()
            );

            // Display formatted summary
            txtSummary.setText(
                    Formatter.formatSummary(
                            getSelectedYear(),
                            monthBox.getSelectedItem().toString(),
                            getSelectedCoverage(),
                            generatedSummary
                    )
            );

            // Enable export button
            btnExport.setEnabled(true);

        } catch (Exception e) {

            e.printStackTrace();

            showError(
                    "Error generating payroll summary."
            );

        }

    }

    // Export Payroll Summary
    private void exportSummary() {

        if (generatedSummary == null) {

            showError(
                    "Please generate the payroll summary first."
            );

            return;

        }

        try {

            boolean saved
                    = PayrollDataHandler.saveSummary(
                            getSelectedYear(),
                            getSelectedMonth(),
                            getSelectedCoverage(),
                            generatedSummary
                    );

            if (saved) {

                showInfo(
                        "Payroll Summary exported successfully!"
                );

            } else {

                showError(
                        "Payroll summary already exists for this period."
                );

            }

        } catch (IOException e) {

            e.printStackTrace();

            showError(
                    "Error exporting payroll summary."
            );

        }

    }
}
