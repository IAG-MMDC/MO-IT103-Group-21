/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.ImageIcon;

import service.AuthService;

/**
 *
 * @author
 */

public class LoginScreen extends JPanel {

    private JTextField txtUser;
    private JPasswordField txtPass;
    private AuthService authService;
    private MainGUIFrame mainGUIFrame;

    public LoginScreen(MainGUIFrame mainGUIFrame) {

        this.mainGUIFrame = mainGUIFrame;
        this.authService = new AuthService();

        setLayout(new GridBagLayout());
        setBackground(new Color(245, 247, 250));

        // Login Card Panel 
        JPanel loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setPreferredSize(new Dimension(420, 450));
        loginPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 10, 8, 10);

        // Title 
        JLabel lblTitle = new JLabel("MotorPH HRIS");
        // Subtitle
        JLabel lblSubtitle = new JLabel("Human Resource Information System");
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitle.setForeground(Color.GRAY);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;

        loginPanel.add(lblSubtitle, gbc);

        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(new Color(25, 42, 86));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(15, 10, 8, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;

        loginPanel.add(lblTitle, gbc);

        // Subtitle
        // Logo Placeholder
        ImageIcon logo = new ImageIcon(
                getClass().getResource("/motorph_logo.png"));

        java.awt.Image image = logo.getImage().getScaledInstance(
                100, // width
                100, // height
                java.awt.Image.SCALE_SMOOTH);

        JLabel lblLogo = new JLabel(new ImageIcon(image));

        lblLogo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblLogo.setForeground(Color.GRAY);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(5, 10, 20, 10);
        gbc.anchor = GridBagConstraints.CENTER;

        loginPanel.add(lblLogo, gbc);

        // Reset Constraints
        gbc.insets = new Insets(6, 10, 6, 10);
        gbc.gridwidth = 1;

        // Username
        JLabel lblUser = new JLabel("Username:");
        lblUser.setForeground(Color.DARK_GRAY);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.WEST;
        loginPanel.add(lblUser, gbc);

        txtUser = new JTextField();
        txtUser.setPreferredSize(new Dimension(160, 30));

        gbc.gridx = 1;
        loginPanel.add(txtUser, gbc);

        // Password
        JLabel lblPass = new JLabel("Password:");
        lblPass.setForeground(Color.DARK_GRAY);

        gbc.gridx = 0;
        gbc.gridy = 4;
        loginPanel.add(lblPass, gbc);

        txtPass = new JPasswordField();
        txtPass.setPreferredSize(new Dimension(160, 30));

        gbc.gridx = 1;
        loginPanel.add(txtPass, gbc);

        // Login Button
        JButton btnLogin = new JButton("Login");

        btnLogin.setBackground(new Color(25, 42, 86));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setBorderPainted(false);
        btnLogin.setOpaque(true);

        btnLogin.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        14));
        
        // Login Button
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        loginPanel.add(btnLogin, gbc);

        btnLogin.addActionListener(e -> login());

        // Press Enter to Login
        javax.swing.SwingUtilities.invokeLater(() -> {
            if (getRootPane() != null) {
                getRootPane().setDefaultButton(btnLogin);
            }
        });

        // Add Card
        add(loginPanel);

    }

    private void login() {
    
        
        if (txtUser.getText().isEmpty() || txtUser.getText().isBlank()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter username.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }
        
        if (txtPass.getText().isEmpty()|| txtPass.getText().isBlank()) {
            
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter password.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }
        
        if (txtUser.getText().isEmpty() || txtUser.getText().isBlank() 
                && txtPass.getText().isEmpty() || txtPass.getText().isBlank()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter username and password.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        String username = txtUser.getText();
        String password = new String(txtPass.getPassword());

        boolean isAuthenticated = authService.authenticate(username, password);

        if (isAuthenticated) {
            JOptionPane.showMessageDialog(
                    this,
                    "Login Sucessful!",
                    "Message",
                    JOptionPane.INFORMATION_MESSAGE
            );

            if (username.equals("employee")) {
                mainGUIFrame.showCard("searchEmployee-Card");
            } else if (username.equals("payroll_staff")) {
                mainGUIFrame.showCard("staffMenu-Card");
            }

        } else {
            
            JOptionPane.showMessageDialog(
                    this,
                    "Invalid credentials.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        clearFields(); 
    }

    private void clearFields() {
        txtUser.setText("");
        txtPass.setText("");
    }
}
