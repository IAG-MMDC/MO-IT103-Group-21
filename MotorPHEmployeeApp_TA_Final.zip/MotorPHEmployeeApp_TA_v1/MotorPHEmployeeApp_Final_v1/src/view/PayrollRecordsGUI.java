/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.Color;
import java.awt.Font;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import model.Attendance;
import model.Employee;
import model.PayrollRecord;

import service.AttendanceDataHandler;
import service.EmployeeDataHandler;
import service.Formatter;
import service.PayrollCalculator;
import service.PayrollDataHandler;

/**
 *
 * @author Home
 */
public class PayrollRecordsGUI extends JPanel {

    // Search Components
    private JTextField txtSearchNo;
    private JTextField txtSearchName;

    private JLabel lblSelectedEmpNo;
    private JLabel lblSelectedEmpName;

    // Payroll Options
    private JComboBox<String> monthBox;
    private JComboBox<Integer> yearBox;
    private JComboBox<String> coverageBox;

    // Display
    private JTextArea displayArea;

    // Buttons
    private JButton btnSearchNo;
    private JButton btnSearchName;

    private JButton btnCalculateOne;
    private JButton btnCalculateAll;
    private JButton btnSave;

    private JButton btnBack;
    private JButton btnLogOut;

    // Data
    private Employee selectedEmployee;

    private List<PayrollRecord> generatedPayroll = new ArrayList<>();

    public PayrollRecordsGUI(MainGUIFrame mainGUIFrame) {

        setLayout(null);
        setBackground(Color.WHITE);
        setOpaque(true);

        createTitle();
        createSearchSection();
        createPayrollOptions();
        createButtons();
        createDisplayArea();

        setupButtonActions(mainGUIFrame);


    }

    // Title 
    private void createTitle() {

        JLabel lblTitle = 
                new JLabel("Payroll Processing");

        lblTitle.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        24));   
        
        lblTitle.setForeground(
                new Color(25, 42, 86));
        
        lblTitle.setBounds(
                20,
                20,
                450,
                40);

        add(lblTitle);

        JLabel lblSubtitle 
                = new JLabel(
                        "Generate payroll for employees, process salaries, and save payroll records.");
               
        lblSubtitle.setFont(
                new Font(
                        "Segoe UI", 
                        Font.PLAIN, 
                        13));
        
        lblSubtitle.setForeground(Color.GRAY);
        
        lblSubtitle.setBounds(
                20,
                60,
                700,
                25);

        add(lblSubtitle);
    }

    // Search Section
    private void createSearchSection() {

        Color navy = new Color(25, 42, 86);

        JLabel lblSearchTitle
                = new JLabel("Employee Search");

        lblSearchTitle.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        16));

        lblSearchTitle.setForeground(navy);

        lblSearchTitle.setBounds(
                20,
                100,
                250,
                30);

        add(lblSearchTitle);

        JLabel lblSearchNo
                = new JLabel("Employee #:");

        lblSearchNo.setBounds(
                20,
                140,
                140,
                25);

        add(lblSearchNo);

        txtSearchNo = new JTextField();

        txtSearchNo.setBounds(
                170,
                140,
                250,
                30);

        add(txtSearchNo);

        btnSearchNo = new JButton("Search");

        btnSearchNo.setBounds(
                435,
                140,
                110,
                30);

        add(btnSearchNo);

        JLabel lblSearchName
                = new JLabel("Employee Name:");

        lblSearchName.setBounds(
                20,
                180,
                140,
                25);

        add(lblSearchName);

        txtSearchName = new JTextField();

        txtSearchName.setBounds(
                170,
                180,
                250,
                30);

        add(txtSearchName);

        btnSearchName = new JButton("Search");

        btnSearchName.setBounds(
                435,
                180,
                110,
                30);

        add(btnSearchName);

        JLabel lblSelected = new JLabel("Selected Employee");
                

        lblSelected.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13));

        lblSelected.setForeground(navy);
        lblSelected.setBounds(
                20,
                220,
                150,
                20);

        add(lblSelected);

        lblSelectedEmpNo = new JLabel("Employee #: -");
        lblSelectedEmpNo.setBounds(
                170,
                220,
                300,
                20);

        add(lblSelectedEmpNo);

        lblSelectedEmpName = new JLabel("Employee Name: -");
        lblSelectedEmpName.setBounds(
                170,
                245,
                300,
                20);

        add(lblSelectedEmpName);
    }

    // Payroll Options
    private void createPayrollOptions() {

        Color navy = new Color(25, 42, 86);

        JLabel lblOptions
                = new JLabel("Payroll Options");

        lblOptions.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        16));

        lblOptions.setForeground(navy);

        lblOptions.setBounds(
                20,
                290,
                250,
                30);

        add(lblOptions);

        // Month Label
        JLabel lblMonth
                = new JLabel("Month:");

        lblMonth.setBounds(
                20,
                330,
                70,
                25);

        add(lblMonth);

        String[] months = {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"
        };

        monthBox
                = new JComboBox<>(months);

        monthBox.setSelectedItem("June");

        monthBox.setBounds(
                110,
                330,
                180,
                30);

        add(monthBox);

        // Year Label
        JLabel lblYear
                = new JLabel("Year:");

        lblYear.setBounds(
                320,
                330,
                50,
                25);

        add(lblYear);

        yearBox
                = new JComboBox<>(
                        new Integer[]{
                            2024,
                            2025,
                            2026
                        });

        yearBox.setBounds(
                380,
                330,
                120,
                30);

        add(yearBox);

        // Coverage Label 
        JLabel lblCoverage
                = new JLabel("Pay Period:");

        lblCoverage.setBounds(
                540,
                330,
                100,
                25);

        add(lblCoverage);

        coverageBox
                = new JComboBox<>(
                        new String[]{
                            PayrollCalculator.FIRST_HALF,
                            PayrollCalculator.SECOND_HALF,
                            PayrollCalculator.WHOLE_MONTH
                        });

        coverageBox.setBounds(
                650,
                330,
                180,
                30);

        add(coverageBox);
    }

   
    // Buttons 
    private void createButtons() {

        Color navy = new Color(25, 42, 86);

        // Process One Button
        btnCalculateOne
                = new JButton(
                        "<html><center>"
                        + "<b>Process One</b><br>"
                        + "<span style='font-size:9px;'>Calculate payroll for one employee</span>"
                        + "</center></html>");

        btnCalculateOne.setBounds(
                820,
                380,
                250,
                70);

        btnCalculateOne.setBackground(navy);
        btnCalculateOne.setForeground(Color.WHITE);
        btnCalculateOne.setFocusPainted(false);
        btnCalculateOne.setBorderPainted(false);
        btnCalculateOne.setOpaque(true);

        btnCalculateOne.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        16));

        add(btnCalculateOne);

        // Process All Button
        btnCalculateAll
                = new JButton(
                        "<html><center>"
                        + "<b>Process All</b><br>"
                        + "<span style='font-size:9px;'>Calculate payroll for all employees</span>"
                        + "</center></html>");

        btnCalculateAll.setBounds(
                820,
                465,
                250,
                70);

        btnCalculateAll.setBackground(navy);
        btnCalculateAll.setForeground(Color.WHITE);
        btnCalculateAll.setFocusPainted(false);
        btnCalculateAll.setBorderPainted(false);
        btnCalculateAll.setOpaque(true);

        btnCalculateAll.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        16));

        add(btnCalculateAll);

        // Save Payroll Button 
        btnSave
                = new JButton(
                        "<html><center>"
                        + "<b>Save Payroll</b><br>"
                        + "<span style='font-size:9px;'>Save payroll records to file</span>"
                        + "</center></html>");

        btnSave.setBounds(
                820,
                550,
                250,
                70);

        btnSave.setBackground(navy);
        btnSave.setForeground(Color.WHITE);
        btnSave.setFocusPainted(false);
        btnSave.setBorderPainted(false);
        btnSave.setOpaque(true);

        btnSave.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        16));

        add(btnSave);

        // Back Button 
        btnBack
                = new JButton("Back");

        btnBack.setBounds(
                820,
                650,
                110,
                35);

        add(btnBack);

        // Log Out Button 
        btnLogOut
                = new JButton("Log Out");

        btnLogOut.setBounds(
                950,
                650,
                120,
                35);

        add(btnLogOut);
    }

    // Display Area
    private void createDisplayArea() {

        displayArea = new JTextArea();

        displayArea.setEditable(false);

        displayArea.setLineWrap(true);

        displayArea.setWrapStyleWord(true);

        displayArea.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        13));

        displayArea.setText("""
            Payroll results will be displayed here.

            • Search for an employee.
            • Select payroll options.
            • Process payroll.
            """);

        JScrollPane scrollPane
                = new JScrollPane(displayArea);

        scrollPane.setBorder(
                BorderFactory.createTitledBorder(
                        "Generated Payroll"));

        scrollPane.setBounds(
                20,
                380,
                760,
                250);

        scrollPane.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        scrollPane.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        add(scrollPane);
    }

    //Helper Methods
    
    // Display an error dialog
    private void showError(String message) {

        JOptionPane.showMessageDialog(
                this,
                message,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );

    }

    // Display an information dialog
    private void showInfo(String message) {

        JOptionPane.showMessageDialog(
                this,
                message,
                "Information",
                JOptionPane.INFORMATION_MESSAGE
        );

    }

    // Display a success dialog
    private void showSuccess(String message) {

        JOptionPane.showMessageDialog(
                this,
                message,
                "Success",
                JOptionPane.INFORMATION_MESSAGE
        );

    }

    // Returns the selected year
    private int getSelectedYear() {

        return (Integer) yearBox.getSelectedItem();

    }

    // Returns the selected month as a number (1-12)
    private int getSelectedMonth() {

        return monthBox.getSelectedIndex() + 1;

    }

    // Returns the selected payroll coverage
    private String getSelectedCoverage() {

        return (String) coverageBox.getSelectedItem();

    }

    // Clears both search text fields
    private void clearSearchFields() {

        txtSearchNo.setText("");
        txtSearchName.setText("");

    }

    // Updates the selected employee labels
    private void updateSelectedEmployeeLabels(Employee employee) {

        lblSelectedEmpNo.setText(
                "Employee #: " + employee.getEmpNo());

        lblSelectedEmpName.setText(
                "Employee Name: "
                + employee.getFirstName()
                + " "
                + employee.getLastName());

    }

    // Displays a formatted payslip
    private void displayPayroll(
            Employee employee,
            PayrollRecord payroll) {

        displayArea.setText(
                Formatter.formatPayslip(
                        employee,
                        payroll
                )
        );

        displayArea.setCaretPosition(0);

    }

    // Builds the display text for all payroll records
    private String buildAllPayrollDisplay(
            List<PayrollRecord> payrollList) {

        StringBuilder sb = new StringBuilder();

        sb.append(
                "============== PAYROLL RECORDS ==============\n\n");

        for (PayrollRecord payroll : payrollList) {

            Employee employee
                    = EmployeeDataHandler.findEmpNo(
                            payroll.getEmpNo());

            if (employee != null) {

                sb.append(
                        Formatter.formatPayslip(
                                employee,
                                payroll));

                sb.append(
                        "\n\n========================================\n\n");

            }

        }

        return sb.toString();

    }
    // Sets up Actions for Buttons
    private void setupButtonActions(MainGUIFrame mainGUIFrame) {

        btnSearchNo.addActionListener(e -> searchEmployeeNo());

        btnSearchName.addActionListener(e -> searchEmployeeName());

        btnCalculateOne.addActionListener(e -> calculateOnePayroll());

        btnCalculateAll.addActionListener(e -> calculateAllPayroll());

        btnSave.addActionListener(e -> savePayroll());

        btnBack.addActionListener(
                e -> mainGUIFrame.showCard("staffMenu-Card"));

        btnLogOut.addActionListener(
                e -> mainGUIFrame.showCard("loginScreen-Card"));
    }
    
    // Employee Look Up Using Employee Number 
    private void searchEmployeeNo() {

        String input = txtSearchNo.getText().trim();

        if (input.isEmpty()) {
            showError("Please enter employee number.");
            return;
        }

        try {

            int empNo = Integer.parseInt(input);

            selectedEmployee = EmployeeDataHandler.findEmpNo(empNo);

            if (selectedEmployee == null) {
                showError("Employee not found.");
                return;
            }

            updateSelectedEmployeeLabels(selectedEmployee);

            displayArea.setText(
                    "Selected Employee\n\n"
                    + "Employee Number: " + selectedEmployee.getEmpNo()
                    + "\nEmployee Name: "
                    + selectedEmployee.getFirstName()
                    + " "
                    + selectedEmployee.getLastName()
                    + "\n\nReady for payroll processing.");

            clearSearchFields();

        } catch (NumberFormatException e) {

            showError("Invalid employee number.");

        }
    }
    
    // Employee Look Up Using Employee Full Name
    private void searchEmployeeName() {

        String input = txtSearchName.getText().trim();

        if (input.isEmpty()) {
            showError("Please enter employee name.");
            return;
        }

        selectedEmployee = null;

        List<Employee> employees = EmployeeDataHandler.readEmployees();

        for (Employee employee : employees) {

            String fullName
                    = employee.getFirstName()
                    + " "
                    + employee.getLastName();

            if (fullName.equalsIgnoreCase(input)) {
                selectedEmployee = employee;
                break;
            }
        }

        if (selectedEmployee == null) {
            showError("Employee not found.");
            return;
        }

        updateSelectedEmployeeLabels(selectedEmployee);

        displayArea.setText(
                "Selected Employee\n\n"
                + "Employee Number: " + selectedEmployee.getEmpNo()
                + "\nEmployee Name: "
                + selectedEmployee.getFirstName()
                + " "
                + selectedEmployee.getLastName()
                + "\n\nReady for payroll processing.");

        clearSearchFields();
    }
    
    // Calculating One Payroll
    private void calculateOnePayroll() {

        if (selectedEmployee == null) {
            showInfo("Please select an employee first.");
            return;
        }

        List<Attendance> attendanceList
                = AttendanceDataHandler.readAttendance();

        PayrollCalculator calculator
                = new PayrollCalculator();

        PayrollRecord payroll
                = calculator.computePayroll(
                        selectedEmployee,
                        attendanceList,
                        getSelectedYear(),
                        getSelectedMonth(),
                        getSelectedCoverage());

        if (payroll == null) {
            showInfo("No attendance record found.");
            return;
        }

        generatedPayroll.clear();
        generatedPayroll.add(payroll);

        displayPayroll(selectedEmployee, payroll);
    }
    
    // Calculating All Payroll
    private void calculateAllPayroll() {

        List<Employee> employees
                = EmployeeDataHandler.readEmployees();

        if (employees.isEmpty()) {
            showInfo("No employees found.");
            return;
        }

        List<Attendance> attendanceList
                = AttendanceDataHandler.readAttendance();

        PayrollCalculator calculator
                = new PayrollCalculator();

        generatedPayroll
                = calculator.computeAllPayroll(
                        employees,
                        attendanceList,
                        getSelectedYear(),
                        getSelectedMonth(),
                        getSelectedCoverage());

        if (generatedPayroll.isEmpty()) {
            displayArea.setText("No payroll generated.");
            return;
        }

        displayArea.setText(
                buildAllPayrollDisplay(generatedPayroll));

        displayArea.setCaretPosition(0);
    }
    
    // Saving Payroll
    private void savePayroll() {

        if (generatedPayroll.isEmpty()) {
            showInfo("Generate payroll first.");
            return;
        }

        try {

            PayrollDataHandler.savePayroll(generatedPayroll);

            showSuccess("Payroll saved successfully.");

        } catch (IOException e) {

            showError(e.getMessage());

        }
    }
}
