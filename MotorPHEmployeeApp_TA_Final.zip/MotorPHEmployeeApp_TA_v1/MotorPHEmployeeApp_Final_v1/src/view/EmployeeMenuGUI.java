/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.Color;
import java.awt.Font;
import java.util.List;
import javax.swing.*;

import model.Attendance;
import model.Employee;
import model.PayrollRecord;

import service.AttendanceDataHandler;
import service.Formatter;
import service.PayrollCalculator;


public class EmployeeMenuGUI extends JPanel {

    // Display
    private JTextArea displayArea;

    // Payroll Options
    private JComboBox<String> monthBox;
    private JComboBox<Integer> yearBox;
    private JComboBox<String> coverageBox;
    
    // Data
    private Employee employee;

    public EmployeeMenuGUI(MainGUIFrame mainGUIFrame){

        setLayout(null);
        setBackground(Color.WHITE);

        createHeader();

        createEmployeeDisplay();

        createPayrollOptions();

        createButtons(mainGUIFrame);

    }

    /* ==============================
     * Header
     ===============================*/
    private void createHeader(){

        JLabel lblTitle =
                new JLabel("Employee Dashboard");


        lblTitle.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        24));


        lblTitle.setForeground(
                new Color(25,42,86));


        lblTitle.setBounds(
                20,20,400,40);


        add(lblTitle);



        JLabel lblSubtitle =
                new JLabel(
                "View your personal information and payslip.");


        lblSubtitle.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        13));


        lblSubtitle.setForeground(Color.GRAY);


        lblSubtitle.setBounds(
                20,60,450,25);


        add(lblSubtitle);

    }
    
    /* ==============================
     * Employee Display 
     ===============================*/
    private void createEmployeeDisplay(){

        JLabel lblInfo =
                new JLabel(
                "Employee Information");


        lblInfo.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        16));


        lblInfo.setForeground(
                new Color(25,42,86));


        lblInfo.setBounds(
                20,100,250,30);


        add(lblInfo);



        displayArea =
                new JTextArea();


        displayArea.setEditable(false);


        displayArea.setFont(
                new Font(
                        "Monospaced",
                        Font.PLAIN,
                        12));



        JScrollPane scrollPane =
                new JScrollPane(displayArea);


        scrollPane.setBounds(
                20,140,430,390);



        scrollPane.setBorder(
                BorderFactory.createTitledBorder(
                        "Employee Information"));



        add(scrollPane);

    }

    /* ==============================
     * Payroll Options
     ===============================*/
    private void createPayrollOptions(){


        JLabel lblOptions =
                new JLabel(
                "Payroll Options");


        lblOptions.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        16));


        lblOptions.setForeground(
                new Color(25,42,86));


        lblOptions.setBounds(
                480,100,220,30);


        add(lblOptions);



        JLabel lblMonth =
                new JLabel("Month:");

        lblMonth.setBounds(
                480,140,70,25);

        add(lblMonth);



        String[] months =
        {
            "January","February",
            "March","April",
            "May","June",
            "July","August",
            "September","October",
            "November","December"
        };


        monthBox =
                new JComboBox<>(months);


        monthBox.setSelectedItem("June");


        monthBox.setBounds(
                590,140,170,30);


        add(monthBox);



        JLabel lblYear =
                new JLabel("Year:");

        lblYear.setBounds(
                480,195,70,25);


        add(lblYear);



        yearBox =
                new JComboBox<>(
                        new Integer[]{
                            2024,
                            2025,
                            2026
                        });


        yearBox.setBounds(
                590,190,170,30);


        add(yearBox);




        JLabel lblCoverage =
                new JLabel(
                "Pay Period:");


        lblCoverage.setBounds(
                480,250,90,25);


        add(lblCoverage);



        coverageBox =
                new JComboBox<>(
                        new String[]{
                            "1 - 15",
                            "16 - 30/31",
                            "1 - 30/31"
                        });



        coverageBox.setBounds(
                590,240,170,30);


        add(coverageBox);


    }

    /* ==============================
     * Buttons
     ===============================*/
    private void createButtons(MainGUIFrame mainGUIFrame){


        JButton btnDetails =
                createButton(
                "View Details",
                500,330);



        JButton btnPayslip =
                createButton(
                "View Payslip",
                500,405);



        JButton btnLogout =
                new JButton("Logout");


        btnLogout.setBounds(
                500,505,110,25);



        add(btnLogout);



        btnDetails.addActionListener(
                e -> showDetails());



        btnPayslip.addActionListener(
                e -> showPayslip());



        btnLogout.addActionListener(
                e -> mainGUIFrame.showCard(
                        "loginScreen-Card"));

    }

    
    /* ==============================
     * Button Style
     ===============================*/
    private JButton createButton(
            String text,
            int x,
            int y){


        JButton button =
                new JButton(text);


        button.setBounds(
                x,y,190,60);


        Color navy =
                new Color(25,42,86);


        button.setBackground(navy);

        button.setForeground(Color.WHITE);

        button.setFocusPainted(false);

        button.setBorderPainted(false);

        button.setOpaque(true);


        button.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        14));


        add(button);


        return button;

    }

    // Shows Employee Details
    private void showDetails(){


        if(employee == null)
            return;


        displayArea.setText(
                Formatter.formatEmployeeProfile(employee)
        );

    }

    // Shows Payslip
    private void showPayslip(){


        if(employee == null)
            return;

        try{


            List<Attendance> attendance =
                    AttendanceDataHandler.readAttendance();

            PayrollCalculator calculator =
                    new PayrollCalculator();

            PayrollRecord payroll =
                    calculator.computePayroll(
                            employee,
                            attendance,
                            getSelectedYear(),
                            getSelectedMonth(),
                            coverageBox.getSelectedItem().toString()
                    );



            if(payroll == null){

                displayArea.setText(
                        "No attendance records found.");

                return;
            }


            displayArea.setText(
                    Formatter.formatPayslip(
                            employee,
                            payroll));


        }catch(Exception e){


            e.printStackTrace();


            displayArea.setText(
                    "Error generating payslip.");

        }
    }

    // Sets Employee
    public void setEmployee(Employee employee){

        this.employee = employee;

    }

    // Helper Method For Month Retrieval
    private int getSelectedMonth(){

        return monthBox.getSelectedIndex()+1;

    }
    // Helper Method For Year Retrieval
    private int getSelectedYear(){

        return (Integer) yearBox.getSelectedItem();

    }
}

