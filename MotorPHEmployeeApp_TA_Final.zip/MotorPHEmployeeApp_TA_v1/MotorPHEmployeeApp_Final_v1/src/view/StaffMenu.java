/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.Font;
import java.util.List;
import javax.swing.JLabel;
import model.Employee;
import service.EmployeeDataHandler;

/**
 *
 * @author Home
 */
public class StaffMenu extends JPanel {

    private JLabel lblTotalEmployees;

    public StaffMenu(MainGUIFrame mainGUIFrame) {

        setLayout(new BorderLayout());

        add(createLeftPanel(mainGUIFrame), BorderLayout.WEST);

        add(createRightPanel(mainGUIFrame), BorderLayout.CENTER);

    }

    // Left Panel Labels 
    private JPanel createLeftPanel(MainGUIFrame mainGUIFrame) {

        JPanel leftPanel = new JPanel();

        leftPanel.setBackground(new Color(25, 42, 86));
        leftPanel.setPreferredSize(new Dimension(220, 0));
        leftPanel.setLayout(null);

        JLabel lblSystem
                = new JLabel("MotorPH HRIS");

        lblSystem.setFont(
                new Font("Segoe UI", Font.BOLD, 20));

        lblSystem.setForeground(Color.WHITE);

        lblSystem.setBounds(
                20, 40, 180, 30);

        leftPanel.add(lblSystem);

        JLabel lblRole
                = new JLabel("Payroll Staff");

        lblRole.setFont(
                new Font("Segoe UI", Font.PLAIN, 13));

        lblRole.setForeground(
                new Color(220, 220, 220));

        lblRole.setBounds(
                20, 70, 150, 20);

        leftPanel.add(lblRole);

        JLabel lblMenu
                = new JLabel("MENU");

        lblMenu.setFont(
                new Font("Segoe UI", Font.BOLD, 11));

        lblMenu.setForeground(
                new Color(220, 220, 220));

        lblMenu.setBounds(
                20, 110, 120, 20);

        leftPanel.add(lblMenu);

        JPanel dashboardPanel
                = new JPanel();

        dashboardPanel.setLayout(null);

        dashboardPanel.setBackground(
                new Color(235, 240, 250));

        dashboardPanel.setBounds(
                20, 145, 180, 45);

        JLabel lblDashboard
                = new JLabel("Dashboard");

        lblDashboard.setFont(
                new Font("Segoe UI",
                        Font.BOLD, 13));

        lblDashboard.setForeground(
                new Color(25, 42, 86));

        lblDashboard.setBounds(
                15, 5, 120, 18);

        dashboardPanel.add(lblDashboard);

        JLabel lblCurrent
                = new JLabel("Current Page");

        lblCurrent.setFont(
                new Font("Segoe UI",
                        Font.PLAIN, 11));

        lblCurrent.setForeground(Color.GRAY);

        lblCurrent.setBounds(
                15, 22, 100, 15);

        dashboardPanel.add(lblCurrent);

        leftPanel.add(dashboardPanel);

        JLabel lblManagement
                = new JLabel("MANAGEMENT");

        lblManagement.setFont(
                new Font("Segoe UI",
                        Font.BOLD, 11));

        lblManagement.setForeground(
                new Color(220, 220, 220));

        lblManagement.setBounds(
                20, 215, 150, 20);

        leftPanel.add(lblManagement);

        JButton btnRecords
                = new JButton("Employee Management");

        btnRecords.setBounds(
                20, 255, 180, 35);

        JButton btnPayroll
                = new JButton("Payroll Processing");

        btnPayroll.setBounds(
                20, 300, 180, 35);

        JButton btnLogOut
                = new JButton("LogOut");

        btnLogOut.setBounds(
                20, 535, 180, 35);

        leftPanel.add(btnRecords);
        leftPanel.add(btnPayroll);
        leftPanel.add(btnLogOut);

        btnRecords.addActionListener(
                e -> mainGUIFrame.showCard(
                        "employeeRecords-Card"));

        btnPayroll.addActionListener(
                e -> mainGUIFrame.showCard(
                        "payrollRecords-Card"));

        btnLogOut.addActionListener(
                e -> mainGUIFrame.showCard(
                        "loginScreen-Card"));

        return leftPanel;

    }

    // Right Panel Labels 
    private JPanel createRightPanel(MainGUIFrame mainGUIFrame) {

        JPanel rightPanel = new JPanel();

        rightPanel.setLayout(null);

        rightPanel.setBackground(Color.WHITE);

        JLabel lblWelcome
                = new JLabel("Welcome to MotorPH HRIS");

        lblWelcome.setFont(
                new Font("Segoe UI",
                        Font.BOLD, 24));

        lblWelcome.setBounds(
                40, 40, 350, 35);

        rightPanel.add(lblWelcome);

        JLabel lblMessage
                = new JLabel(
                        "<html>"
                        + "Good day, Payroll Staff!<br><br>"
                        + "Use the menu on the left to manage employee "
                        + "records and payroll information."
                        + "</html>");

        lblMessage.setFont(
                new Font("Segoe UI",
                        Font.PLAIN, 15));

        lblMessage.setBounds(
                40, 90, 420, 100);

        rightPanel.add(lblMessage);

        rightPanel.add(
                createDashboardCard(
                        "Employee Management",
                        "• Manage employee records<br>"
                        + "• Update employee information<br>"
                        + "• Maintain employee list",
                        40,
                        190,
                        e -> mainGUIFrame.showCard(
                                "employeeRecords-Card"))
        );

        rightPanel.add(
                createDashboardCard(
                        "Payroll Processing",
                        "• Process payroll<br>"
                        + "• Calculate salaries<br>"
                        + "• Generate payslips",
                        360,
                        190,
                        e -> mainGUIFrame.showCard(
                                "payrollRecords-Card"))
        );

        rightPanel.add(
                createTotalEmployeeWidget()
        );

        rightPanel.add(
                createSystemInfoWidget()
        );

        rightPanel.add(
                createQuickAccessWidget()
        );

        rightPanel.add(
                createDashboardCard(
                        "Payroll Summary",
                        "• View payroll reports<br>"
                        + "• View salary summaries<br>"
                        + "• View statistics",
                        40,
                        390,
                        e -> mainGUIFrame.showCard(
                                "payrollSummary-Card"))
        );

        return rightPanel;

    }

    //
    private JPanel createTotalEmployeeWidget() {

        JPanel totalPanel = new JPanel();

        totalPanel.setLayout(null);

        totalPanel.setBackground(
                new Color(245, 245, 245));

        totalPanel.setBounds(
                650, 190, 200, 170);

        totalPanel.setBorder(
                javax.swing.BorderFactory
                        .createLineBorder(
                                new Color(210, 210, 210)));

        JLabel lblTitle
                = new JLabel("Total Employees");

        lblTitle.setFont(
                new Font("Segoe UI",
                        Font.BOLD, 16));

        lblTitle.setBounds(
                20, 15, 150, 25);

        totalPanel.add(lblTitle);

        lblTotalEmployees
                = new JLabel("0");

        lblTotalEmployees.setFont(
                new Font("Segoe UI",
                        Font.BOLD, 42));

        lblTotalEmployees.setHorizontalAlignment(
                JLabel.CENTER);

        lblTotalEmployees.setBounds(
                20, 55, 140, 50);

        totalPanel.add(lblTotalEmployees);

        JLabel lblFooter
                = new JLabel("Registered Employees");

        lblFooter.setFont(
                new Font("Segoe UI",
                        Font.PLAIN, 12));

        lblFooter.setForeground(Color.GRAY);

        lblFooter.setHorizontalAlignment(
                JLabel.CENTER);

        lblFooter.setBounds(
                20, 120, 140, 20);

        totalPanel.add(lblFooter);

        updateEmployeeCount();

        return totalPanel;

    }

    // Added
    private JPanel createSystemInfoWidget() {

        JPanel systemPanel = new JPanel();

        systemPanel.setLayout(null);

        systemPanel.setBackground(
                new Color(245, 245, 245));

        systemPanel.setBounds(
                650,
                380,
                200,
                170);

        systemPanel.setBorder(
                javax.swing.BorderFactory.createLineBorder(
                        new Color(210, 210, 210)));

        JLabel lblSystemTitle
                = new JLabel("System Info");

        lblSystemTitle.setFont(
                new Font("Segoe UI",
                        Font.BOLD,
                        16));

        lblSystemTitle.setBounds(
                20,
                15,
                150,
                25);

        systemPanel.add(lblSystemTitle);

        JLabel lblUserTitle
                = new JLabel("User");

        lblUserTitle.setFont(
                new Font("Segoe UI",
                        Font.BOLD,
                        12));

        lblUserTitle.setBounds(
                20,
                55,
                100,
                20);

        systemPanel.add(lblUserTitle);

        JLabel lblUserValue
                = new JLabel("Payroll Staff");

        lblUserValue.setFont(
                new Font("Segoe UI",
                        Font.PLAIN,
                        13));

        lblUserValue.setBounds(
                20,
                75,
                140,
                20);

        systemPanel.add(lblUserValue);

        JLabel lblStatusTitle
                = new JLabel("Status");

        lblStatusTitle.setFont(
                new Font("Segoe UI",
                        Font.BOLD,
                        12));

        lblStatusTitle.setBounds(
                20,
                110,
                100,
                20);

        systemPanel.add(lblStatusTitle);

        JLabel lblStatusValue
                = new JLabel("Ready");

        lblStatusValue.setFont(
                new Font("Segoe UI",
                        Font.BOLD,
                        13));

        lblStatusValue.setForeground(
                new Color(34, 139, 34));

        lblStatusValue.setBounds(
                20,
                130,
                100,
                20);

        systemPanel.add(lblStatusValue);

        return systemPanel;
    }

    private JPanel createQuickAccessWidget() {

        JPanel tipsPanel = new JPanel();

        tipsPanel.setLayout(null);

        tipsPanel.setBackground(
                new Color(245, 245, 245));

        tipsPanel.setBounds(
                650,
                570,
                200,
                180);

        tipsPanel.setBorder(
                javax.swing.BorderFactory.createLineBorder(
                        new Color(210, 210, 210)));

        JLabel lblTipsTitle
                = new JLabel("Quick Access");

        lblTipsTitle.setFont(
                new Font("Segoe UI",
                        Font.BOLD,
                        16));

        lblTipsTitle.setBounds(
                20,
                15,
                150,
                25);

        tipsPanel.add(lblTipsTitle);

        JLabel lblTips
                = new JLabel(
                        "<html>"
                        + "Logged in as:<br>"
                        + "<b>Payroll Staff</b><br><br>"
                        + "✓ Employee Management<br>"
                        + "✓ Payroll Processing<br>"
                        + "✓ Reports"
                        + "</html>"
                );

        lblTips.setFont(
                new Font("Segoe UI",
                        Font.PLAIN,
                        12));

        lblTips.setBounds(
                20,
                45,
                160,
                110);

        tipsPanel.add(lblTips);

        return tipsPanel;

    }

    private JPanel createDashboardCard(
            String title,
            String description,
            int x,
            int y,
            java.awt.event.ActionListener action) {

        JPanel card = new JPanel();

        card.setLayout(null);

        card.setBackground(
                new Color(245, 245, 245));

        card.setBounds(
                x,
                y,
                260,
                170);

        card.setBorder(
                javax.swing.BorderFactory.createLineBorder(
                        new Color(210, 210, 210)));

        String displayTitle
                = title.equals("Employee Management")
                ? "<html>Employee<br>Management</html>"
                : title;

        JLabel lblTitle
                = new JLabel(displayTitle);

        lblTitle.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        17));

        lblTitle.setBounds(
                20,
                15,
                200,
                50);

        JLabel lblDescription
                = new JLabel(
                        "<html>"
                        + description
                        + "</html>");

        lblDescription.setFont(
                new Font(
                        "Segoe UI",
                        Font.PLAIN,
                        12));

        lblDescription.setBounds(
                20,
                65,
                220,
                60);

        JButton btnOpen
                = new JButton("OPEN");

        btnOpen.setBounds(
                55,
                125,
                150,
                28);

        btnOpen.addActionListener(action);

        card.add(lblTitle);

        card.add(lblDescription);

        card.add(btnOpen);

        return card;
    }

    private void updateEmployeeCount() {

        try {

            List<Employee> employees
                    = EmployeeDataHandler.readEmployees();

            lblTotalEmployees.setText(
                    String.valueOf(
                            employees.size()
                    )
            );

        } catch (Exception e) {

            e.printStackTrace();

            lblTotalEmployees.setText("0");

        }

    }

    public void refreshDashboard() {
        updateEmployeeCount();
    }
}
