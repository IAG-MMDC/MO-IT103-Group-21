/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.CardLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import model.Employee;

/**
 *
 * @author Home
 */
public class MainGUIFrame extends JFrame {

    private CardLayout cardLayout;
    private JPanel rootPanel;
    private EmployeeMenuGUI employeeMenu;
    private ImageIcon image;
    private StaffMenu staffMenu;

    public MainGUIFrame() {

        setTitle("MotorPH Employee App");
        image = new ImageIcon("logo.png");
        setIconImage(image.getImage());
        setSize(1280, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        LoginScreen login = new LoginScreen(this);
        SearchEmployee searchEmployee = new SearchEmployee(this);
        employeeMenu = new EmployeeMenuGUI(this);
        staffMenu = new StaffMenu(this);
        EmployeeRecords employeeRecords = new EmployeeRecords(this);
        PayrollRecordsGUI payrollRecords = new PayrollRecordsGUI(this);
        PayrollSummaryGUI payrollSummary = new PayrollSummaryGUI(this);

        cardLayout = new CardLayout();
        rootPanel = new JPanel(cardLayout);

        rootPanel.add(login, "loginScreen-Card");
        rootPanel.add(searchEmployee, "searchEmployee-Card");
        rootPanel.add(employeeMenu, "employeeMenu-Card");
        rootPanel.add(staffMenu, "staffMenu-Card");
        rootPanel.add(employeeRecords, "employeeRecords-Card");
        rootPanel.add(payrollRecords, "payrollRecords-Card");
        rootPanel.add(payrollSummary, "payrollSummary-Card");

        add(rootPanel);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    // Show Card
    public void showCard(String cardName) {

        if (cardName.equals("staffMenu-Card")) {
            staffMenu.refreshDashboard();
        }

        cardLayout.show(rootPanel, cardName);
    }

    // Show Employee Menu
    public void showEmployeeMenu(Employee employee) {
        employeeMenu.setEmployee(employee);
        showCard("employeeMenu-Card");
    }
}
