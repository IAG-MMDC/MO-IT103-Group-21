/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import model.Employee;
import service.EmployeeDataHandler;

/**
 *
 * @author Home
 */
public class SearchEmployee extends JPanel {

    private final MainGUIFrame mainGUIFrame;
    private final JTextField txtEmpNo;

    public SearchEmployee(MainGUIFrame mainGUIFrame) {
        this.mainGUIFrame = mainGUIFrame;
  
        
        setLayout(new GridBagLayout());
        setBackground(new Color(245, 247, 250));

        GridBagConstraints outer = new GridBagConstraints();
        outer.gridx = 0;
        outer.gridy = 0;

        // Card Panel
        JPanel searchPanel = new JPanel(new GridBagLayout());
        searchPanel.setPreferredSize(new Dimension(400, 340));
        searchPanel.setBackground(Color.WHITE);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 10, 8, 10);

        // Title 
        JLabel lblTitle = new JLabel("MotorPH Employee App");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(new Color(25, 42, 86));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(15, 10, 25, 10);
        gbc.anchor = GridBagConstraints.CENTER;
        searchPanel.add(lblTitle, gbc);

        // Reset Constraints 
        gbc.insets = new Insets(6, 10, 6, 10);
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;

        // Label
        JLabel lblSearchNo = new JLabel("Search Employee #:");
        lblSearchNo.setForeground(Color.DARK_GRAY);

        gbc.gridx = 0;
        gbc.gridy = 1;
        searchPanel.add(lblSearchNo, gbc);

        // Text Field
        txtEmpNo = new JTextField();
        txtEmpNo.setPreferredSize(new Dimension(160, 25));

        gbc.gridx = 1;
        searchPanel.add(txtEmpNo, gbc);

        // Buttons
        JButton btnSearch = new JButton("Search");
        JButton btnClear = new JButton("Clear");

        Color navy = new Color(25, 42, 86);

        btnSearch.setBackground(navy);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFocusPainted(false);
        btnSearch.setBorderPainted(false);
        btnSearch.setOpaque(true);

        btnSearch.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13));

        btnClear.setBackground(new Color(230, 230, 230));
        btnClear.setFocusPainted(false);

        btnClear.setFont(
                new Font(
                        "Segoe UI",
                        Font.BOLD,
                        13));
        btnClear.setBorderPainted(false);
        btnClear.setOpaque(true);

        Dimension btnSize = new Dimension(80, 30);
        btnSearch.setPreferredSize(btnSize);
        btnClear.setPreferredSize(btnSize);

        // Button panel
        JPanel buttonPanel = new JPanel(
                new java.awt.FlowLayout(
                        java.awt.FlowLayout.CENTER,
                        10,
                        0));

        buttonPanel.setBackground(Color.WHITE);

        buttonPanel.add(btnSearch);
        buttonPanel.add(btnClear);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        searchPanel.add(buttonPanel, gbc);

        // Button Actions
        btnSearch.addActionListener(e -> searchEmployee());
        btnClear.addActionListener(e -> clearSearch());

        // Add Panel
        add(searchPanel, outer);
    }

    // Search Employee
    private void searchEmployee() {
        
        
        String input = txtEmpNo.getText().trim();

        if (input.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter an employee number.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        if (!input.matches("\\d+")) {
            JOptionPane.showMessageDialog(
                    this,
                    "Employee number must contain numbers only.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        int empNo = Integer.parseInt(input);

        Employee employee = EmployeeDataHandler.findEmpNo(empNo);

        if (employee != null) {

            mainGUIFrame.showEmployeeMenu(employee); 

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Employee not found.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
        clearSearch();
    }

    // Clear Fields
    private void clearSearch() {
        txtEmpNo.setText("");
    }
}
