/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.awt.Color;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import model.Employee;
import service.EmployeeDataHandler;
import java.awt.Font;

/**
 *
 * @author Home
 */
public class EmployeeRecords extends JPanel {

    private JTextField txtEmpNo, txtFirstN, txtLastN;
    private JTextField txtBirthday, txtAddress, txtPhoneN, txtSSS, txtPhilHealth, txtTIN, txtPagIBIG,
            txtStatus, txtPosition, txtImmediate, txtBasic, txtRice, txtPhoneAl, txtClothing,
            txtGross, txtHourly;

    private DefaultTableModel tableModel;
    private JTable employeeTable;

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    
    

    public EmployeeRecords(MainGUIFrame mainGUIFrame) {

        setLayout(null);
        setBackground(Color.WHITE);
        setOpaque(true);

        // Page Title
        JLabel lblTitle = new JLabel("Employee Management");

        lblTitle.setFont(
                new Font("Segoe UI",
                        Font.BOLD,
                        24));

        lblTitle.setForeground(
                new Color(25, 42, 86));

        lblTitle.setBounds(20, 20, 450, 40);

        add(lblTitle);

        JLabel lblSubtitle
                = new JLabel(
                        "Manage employee records, search employees, and maintain employee information.");

        lblSubtitle.setFont(
                new Font("Segoe UI",
                        Font.PLAIN,
                        13));

        lblSubtitle.setForeground(Color.GRAY);

        lblSubtitle.setBounds(20, 60, 600, 25);

        add(lblSubtitle);

        // Employee Information Heading
        JLabel lblEmployeeInfo
                = new JLabel("Employee Information");

        lblEmployeeInfo.setFont(
                new Font("Segoe UI",
                        Font.BOLD,
                        16));

        lblEmployeeInfo.setForeground(
                new Color(25, 42, 86));

        lblEmployeeInfo.setBounds(55, 95, 250, 30);

        add(lblEmployeeInfo);

        // Compensation and Benefits Heading
        JLabel lblBenefits
                = new JLabel("Compensation & Benefits");

        lblBenefits.setFont(
                new Font("Segoe UI",
                        Font.BOLD,
                        16));

        lblBenefits.setForeground(
                new Color(25, 42, 86));

        lblBenefits.setBounds(
                390,
                95,
                250,
                30);

        add(lblBenefits);

        // Employement and Salary Heading
        JLabel lblSalaryInfo
                = new JLabel("Employment & Salary");

        lblSalaryInfo.setFont(
                new Font("Segoe UI",
                        Font.BOLD,
                        16));

        lblSalaryInfo.setForeground(
                new Color(25, 42, 86));

        lblSalaryInfo.setBounds(
                850,
                95,
                250,
                30);

        add(lblSalaryInfo);

        // Labels and Text Fields
        JLabel lblEmpNo = new JLabel("Employee #:");
        lblEmpNo.setBounds(20, 135, 90, 25);
        add(lblEmpNo);

        txtEmpNo = new JTextField();
        txtEmpNo.setBounds(120, 135, 150, 25);
        add(txtEmpNo);

        JLabel lblLastN = new JLabel("Last Name:");
        lblLastN.setBounds(20, 195, 90, 25);
        add(lblLastN);

        txtLastN = new JTextField();
        txtLastN.setBounds(120, 195, 150, 25);
        add(txtLastN);

        JLabel lblFirstN = new JLabel("First Name:");
        lblFirstN.setBounds(20, 165, 90, 25);
        add(lblFirstN);

        txtFirstN = new JTextField();
        txtFirstN.setBounds(120, 165, 150, 25);
        add(txtFirstN);

        JLabel lblBirthday = new JLabel("Birthday:");
        lblBirthday.setBounds(20, 225, 90, 25);
        add(lblBirthday);

        txtBirthday = new JTextField();
        txtBirthday.setBounds(120, 225, 150, 25);
        add(txtBirthday);

        JLabel lblAddress = new JLabel("Address:");
        lblAddress.setBounds(20, 255, 90, 25);
        add(lblAddress);

        txtAddress = new JTextField();
        txtAddress.setBounds(120, 255, 150, 25);
        add(txtAddress);

        JLabel lblPhoneN = new JLabel("Phone #:");
        lblPhoneN.setBounds(20, 285, 90, 25);
        add(lblPhoneN);

        txtPhoneN = new JTextField();
        txtPhoneN.setBounds(120, 285, 150, 25);
        add(txtPhoneN);

        JLabel lblSSS = new JLabel("SSS #:");
        lblSSS.setBounds(370, 135, 140, 25);
        add(lblSSS);

        txtSSS = new JTextField();
        txtSSS.setBounds(510, 135, 150, 25);
        add(txtSSS);

        JLabel lblPhilHealth = new JLabel("PhiHealth #:");
        lblPhilHealth.setBounds(370, 165, 140, 25);
        add(lblPhilHealth);

        txtPhilHealth = new JTextField();
        txtPhilHealth.setBounds(510, 165, 150, 25);
        add(txtPhilHealth);

        JLabel lblTIN = new JLabel("TIN #:");
        lblTIN.setBounds(370, 195, 140, 25);
        add(lblTIN);

        txtTIN = new JTextField();
        txtTIN.setBounds(510, 195, 150, 25);
        add(txtTIN);

        JLabel lblPagIBIG = new JLabel("PagIBIG #:");
        lblPagIBIG.setBounds(370, 225, 140, 25);
        add(lblPagIBIG);

        txtPagIBIG = new JTextField();
        txtPagIBIG.setBounds(510, 225, 150, 25);
        add(txtPagIBIG);

        JLabel lblStatus = new JLabel("Status:");
        lblStatus.setBounds(790, 135, 170, 25);
        add(lblStatus);

        txtStatus = new JTextField();
        txtStatus.setBounds(970, 135, 150, 25);
        add(txtStatus);

        JLabel lblPosition = new JLabel("Position:");
        lblPosition.setBounds(790, 165, 170, 25);
        add(lblPosition);

        txtPosition = new JTextField();
        txtPosition.setBounds(970, 165, 150, 25);
        add(txtPosition);

        JLabel lblImmediate = new JLabel("Immediate Supervisor:");
        lblImmediate.setBounds(790, 195, 170, 25);
        add(lblImmediate);

        txtImmediate = new JTextField();
        txtImmediate.setBounds(970, 195, 150, 25);
        add(txtImmediate);

        JLabel lblBasic = new JLabel("Basic Salary:");
        lblBasic.setBounds(790, 225, 170, 25);
        add(lblBasic);

        txtBasic = new JTextField();
        txtBasic.setBounds(970, 225, 150, 25);
        add(txtBasic);

        JLabel lblRice = new JLabel("Rice Subsidy:");
        lblRice.setBounds(370, 255, 140, 25);
        add(lblRice);

        txtRice = new JTextField();
        txtRice.setBounds(510, 255, 150, 25);
        add(txtRice);

        JLabel lblPhoneAl = new JLabel("Phone Allowance:");
        lblPhoneAl.setBounds(370, 285, 140, 25);
        add(lblPhoneAl);

        txtPhoneAl = new JTextField();
        txtPhoneAl.setBounds(510, 285, 150, 25);
        add(txtPhoneAl);

        JLabel lblClothing = new JLabel("Clothing Allowance:");
        lblClothing.setBounds(370, 315, 140, 25);
        add(lblClothing);

        txtClothing = new JTextField();
        txtClothing.setBounds(510, 315, 150, 25);
        add(txtClothing);

        JLabel lblGross = new JLabel("Gross Semi-Monthly Rate: ");
        lblGross.setBounds(790, 255, 170, 25);
        add(lblGross);

        txtGross = new JTextField();
        txtGross.setBounds(970, 255, 150, 25);
        add(txtGross);

        JLabel lblHourly = new JLabel("Hourly Rate: ");
        lblHourly.setBounds(790, 285, 170, 25);
        add(lblHourly);

        txtHourly = new JTextField();
        txtHourly.setBounds(970, 285, 150, 25);
        add(txtHourly);

        // Buttons
        JButton btnView = new JButton("View All");
        btnView.setBounds(945, 375, 150, 35);
        add(btnView);

        JButton btnAdd = new JButton("Add");
        btnAdd.setBounds(945, 420, 150, 35);
        add(btnAdd);

        JButton btnUpdate = new JButton("Update");
        btnUpdate.setBounds(945, 465, 150, 35);
        add(btnUpdate);

        JButton btnDelete = new JButton("Delete");
        btnDelete.setBounds(945, 510, 150, 35);
        add(btnDelete);

        JButton btnClear = new JButton("Clear");
        btnClear.setBounds(
                945,
                555,
                150,
                35);
        add(btnClear);

        Color navy = new Color(25, 42, 86);

        JButton[] buttons = {
            btnView,
            btnAdd,
            btnUpdate,
            btnDelete,
            btnClear
        };

        for (JButton button : buttons) {
            button.setBackground(navy);
            button.setForeground(Color.WHITE);
            button.setFocusPainted(false);
            button.setBorderPainted(false);
            button.setOpaque(true);
            button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        }

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(945, 600, 150, 35);
        add(btnBack);

        JButton btnLogOut = new JButton("Log Out");
        btnLogOut.setBounds(945, 645, 150, 35);
        add(btnLogOut);

        // Table 
        tableModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableModel.addColumn("Employee #");
        tableModel.addColumn("Last Name");
        tableModel.addColumn("First Name");
        tableModel.addColumn("Birthday");
        tableModel.addColumn("Address");
        tableModel.addColumn("Phone #");
        tableModel.addColumn("SSS #");
        tableModel.addColumn("PhiHealth #");
        tableModel.addColumn("TIN #");
        tableModel.addColumn("Pag-IBIG #");
        tableModel.addColumn("Status");
        tableModel.addColumn("Position");
        tableModel.addColumn("Immediate Supervisor");
        tableModel.addColumn("Basic Salary");
        tableModel.addColumn("Rice Subsidy");
        tableModel.addColumn("Phone Allowance");
        tableModel.addColumn("Clothing Allowance");
        tableModel.addColumn("Gross Semi-Monthly Rate");
        tableModel.addColumn("Hourly Rate");

        employeeTable = new JTable(tableModel);

        employeeTable.getSelectionModel().addListSelectionListener(e -> {

            if (e.getValueIsAdjusting()) {
                return;
            }

            int row = employeeTable.getSelectedRow();

            if (row >= 0) {

                txtEmpNo.setText(tableModel.getValueAt(row, 0).toString());
                txtLastN.setText(tableModel.getValueAt(row, 1).toString());
                txtFirstN.setText(tableModel.getValueAt(row, 2).toString());
                txtBirthday.setText(tableModel.getValueAt(row, 3).toString());
                txtAddress.setText(tableModel.getValueAt(row, 4).toString());
                txtPhoneN.setText(tableModel.getValueAt(row, 5).toString());
                txtSSS.setText(tableModel.getValueAt(row, 6).toString());
                txtPhilHealth.setText(tableModel.getValueAt(row, 7).toString());
                txtTIN.setText(tableModel.getValueAt(row, 8).toString());
                txtPagIBIG.setText(tableModel.getValueAt(row, 9).toString());
                txtStatus.setText(tableModel.getValueAt(row, 10).toString());
                txtPosition.setText(tableModel.getValueAt(row, 11).toString());
                txtImmediate.setText(tableModel.getValueAt(row, 12).toString());
                txtBasic.setText(tableModel.getValueAt(row, 13).toString());
                txtRice.setText(tableModel.getValueAt(row, 14).toString());
                txtPhoneAl.setText(tableModel.getValueAt(row, 15).toString());
                txtClothing.setText(tableModel.getValueAt(row, 16).toString());
                txtGross.setText(tableModel.getValueAt(row, 17).toString());
                txtHourly.setText(tableModel.getValueAt(row, 18).toString());

                txtEmpNo.setEditable(false);

            }
        });

        employeeTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        employeeTable.getColumnModel().getColumn(0).setPreferredWidth(80);

        // Search Employee
        JLabel lblSearch = new JLabel("Search Employee #:");
        lblSearch.setBounds(20, 625, 140, 25);
        add(lblSearch);

        JTextField txtSearch = new JTextField();
        txtSearch.setBounds(165, 625, 180, 25);
        add(txtSearch);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBounds(360, 625, 100, 25);
        add(btnSearch);

        // Employee Directory Heading
        JLabel lblDirectory
                = new JLabel("Employee Directory");

        lblDirectory.setFont(
                new Font("Segoe UI",
                        Font.BOLD,
                        16));

        lblDirectory.setForeground(
                new Color(25, 42, 86));

        lblDirectory.setBounds(
                20,
                345,
                250,
                28);

        add(lblDirectory);

        // JScroll Pane
        JScrollPane scrollPane = new JScrollPane(employeeTable);
        scrollPane.setBounds(20, 375, 900, 240);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        add(scrollPane);

        // Button Actions
        btnView.addActionListener(e -> viewEmployees());
        btnAdd.addActionListener(e -> addEmployee());
        btnUpdate.addActionListener(e -> updateEmployee());
        btnDelete.addActionListener(e -> deleteEmployee());
        btnClear.addActionListener(e -> clearFields());
        btnSearch.addActionListener(e -> searchEmployee(txtSearch.getText()));
        btnBack.addActionListener(e -> mainGUIFrame.showCard("staffMenu-Card"));
        btnLogOut.addActionListener(e -> mainGUIFrame.showCard("loginScreen-Card"));

        viewEmployees();
    }

    // View Employees
    private void viewEmployees() {
        List<Employee> employees = EmployeeDataHandler.readEmployees(); 

        tableModel.setRowCount(0);
       
        for (Employee employee : employees) {
            addEmployeeToTable(employee);
        }
        clearFields(); 
    }

    // Add Employee
    private void addEmployee() {
        
        if (!validateRequiredFields()) {
            return;
        }
        try {
            Employee employee = createEmployeeFromFields();

            EmployeeDataHandler.addEmployee(employee);

            showInfo("Employee added successfully!");

            viewEmployees();

            clearFields();

        } catch (IllegalArgumentException e) {

            showError(e.getMessage());

        } catch (Exception e) {

            e.printStackTrace();

            showError("Unexpected error occured.");
        }
    }

    // Update Employee
    private void updateEmployee() {
       
        if (employeeTable.getSelectedRow() == -1) {

            showError("Please select an employee first.");

            return;
        }

        if (!validateRequiredFields()) {
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Update selected employee?",
                "Confirm Update",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {

            Employee employee = createEmployeeFromFields();

            EmployeeDataHandler.updateEmployee(employee);

            showInfo("Employee updated successfully!");

            viewEmployees();

            clearFields();

        } catch (IllegalArgumentException e) {

            showError(e.getMessage());

        } catch (Exception e) {

            e.printStackTrace();

            showError("Unexpected error occurred.");
        }
    }

    // Delete Employee
    private void deleteEmployee() {

      
        int selectedRow = employeeTable.getSelectedRow();

        if (selectedRow == -1) {
            showError("Please select an employee first.");
            return;
        }

        int empNo = Integer.parseInt(
                tableModel.getValueAt(selectedRow, 0).toString());

        String employeeName
                = tableModel.getValueAt(selectedRow, 1)
                + ", "
                + tableModel.getValueAt(selectedRow, 2);

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete:\n\n"
                + employeeName + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        EmployeeDataHandler.deleteEmployee(empNo);

        showInfo("Employee deleted successfully.");

        viewEmployees();

        clearFields();

    }

    // Clear Fields 
    private void clearFields() {
        txtEmpNo.setText("");
        txtLastN.setText("");
        txtFirstN.setText("");
        txtBirthday.setText("");
        txtAddress.setText("");
        txtPhoneN.setText("");
        txtSSS.setText("");
        txtPhilHealth.setText("");
        txtTIN.setText("");
        txtPagIBIG.setText("");
        txtStatus.setText("");
        txtPosition.setText("");
        txtImmediate.setText("");
        txtBasic.setText("");
        txtRice.setText("");
        txtPhoneAl.setText("");
        txtClothing.setText("");
        txtGross.setText("");
        txtHourly.setText("");

        employeeTable.clearSelection();

        txtEmpNo.setEditable(true);

        txtEmpNo.requestFocus();
    }

    // Search Employee
    private void searchEmployee(String keyword) {
       

        keyword = keyword.trim();

        if (keyword.isBlank()) {
            showError("Please enter an Employee Number, First Name, or Last Name.");
            return;
        }

        List<Employee> employees = EmployeeDataHandler.readEmployees();

        tableModel.setRowCount(0);

        boolean found = false;

        for (Employee employee : employees) {

            if (String.valueOf(employee.getEmpNo()).equalsIgnoreCase(keyword)
                    || employee.getFirstName().equalsIgnoreCase(keyword)
                    || employee.getLastName().equalsIgnoreCase(keyword)) {

                addEmployeeToTable(employee);
                found = true;
            }
        }

        if (!found) {
            showInfo("Employee not found.");
        }

    }

    //added
    private boolean validateRequiredFields() {

        return !(isBlankField(txtEmpNo, "Employee Number")
                || isBlankField(txtLastN, "Last Name")
                || isBlankField(txtFirstN, "First Name")
                || isBlankField(txtBirthday, "Birthday")
                || isBlankField(txtAddress, "Address")
                || isBlankField(txtPhoneN, "Phone Number")
                || isBlankField(txtSSS, "SSS Number")
                || isBlankField(txtPhilHealth, "PhilHealth Number")
                || isBlankField(txtTIN, "TIN Number")
                || isBlankField(txtPagIBIG, "Pag-IBIG Number")
                || isBlankField(txtStatus, "Status")
                || isBlankField(txtPosition, "Position")
                || isBlankField(txtImmediate, "Immediate Supervisor")
                || isBlankField(txtBasic, "Basic Salary")
                || isBlankField(txtRice, "Rice Subsidy")
                || isBlankField(txtPhoneAl, "Phone Allowance")
                || isBlankField(txtClothing, "Clothing Allowance")
                || isBlankField(txtGross, "Gross Semi-Monthly Rate")
                || isBlankField(txtHourly, "Hourly Rate"));
    }

    // Validation Check
    private boolean isBlankField(JTextField field, String fieldName) {

        if (field.getText().trim().isBlank()) {

            showError(fieldName + " is required.");

            field.requestFocus();

            return true;
        }

        return false;
    }
    
    // Employee Form Fields
    private Employee createEmployeeFromFields() {

        return new Employee(
                parseIntField(txtEmpNo, "Employee Number"),
                txtLastN.getText().trim(),
                txtFirstN.getText().trim(),
                parseDateField(txtBirthday, "Birthday"),
                txtAddress.getText().trim(),
                validatePhoneNumber(txtPhoneN),
                validateGovernmentID(txtSSS, "SSS Number"),
                validateGovernmentID(txtPhilHealth, "PhilHealth Number"),
                validateGovernmentID(txtTIN, "TIN Number"),
                validateGovernmentID(txtPagIBIG, "PagIBIG Number"),
                txtStatus.getText().trim(),
                txtPosition.getText().trim(),
                txtImmediate.getText().trim(),
                parseIntField(txtBasic, "Basic Salary"),
                parseIntField(txtRice, "Rice Subsidy"),
                parseIntField(txtPhoneAl, "Phone Allowance"),
                parseIntField(txtClothing, "Clothing Allowance"),
                parseIntField(txtGross, "Gross Semi-Monthly Rate"),
                parseDoubleField(txtHourly, "Hourly Rate")
        );
    }

    //Parse Int Field
    private int parseIntField(JTextField field, String fieldName) {

        try {

            return Integer.parseInt(field.getText().trim());

        } catch (NumberFormatException e) {

            field.requestFocus();

            throw new IllegalArgumentException(
                    fieldName + " must be a valid whole number.");
        }
    }

    // Parse Double Field
    private double parseDoubleField(JTextField field, String fieldName) {

        try {

            return Double.parseDouble(field.getText().trim());

        } catch (NumberFormatException e) {

            field.requestFocus();

            throw new IllegalArgumentException(
                    fieldName + " must be a valid decimal number.");
        }
    }

    private LocalDate parseDateField(JTextField field, String fieldName) {

        try {

            return LocalDate.parse(
                    field.getText().trim(),
                    DATE_FORMAT);

        } catch (DateTimeParseException e) {

            field.requestFocus();

            throw new IllegalArgumentException(
                    fieldName + " must be in MM/dd/yyyy format.");
        }
    }

    // added
    private String validatePhoneNumber(JTextField field) {

        String value = field.getText().trim();

        if (!value.matches("\\d{11}")) {

            field.requestFocus();

            throw new IllegalArgumentException(
                    "Phone Number must contain exactly 11 digits.");
        }

        return value;
    }

    private String validateGovernmentID(JTextField field,
            String fieldName) {

        String value = field.getText().trim();

        if (!value.matches("[0-9-]+")) {

            field.requestFocus();

            throw new IllegalArgumentException(
                    fieldName
                    + " must contain only numbers and hyphens.");
        }

        return value;
    }

    private void addEmployeeToTable(Employee employee) {

        tableModel.addRow(new Object[]{
            employee.getEmpNo(),
            employee.getLastName(),
            employee.getFirstName(),
            employee.getBirthday().format(DATE_FORMAT),
            employee.getAddress(),
            employee.getPhoneNumber(),
            employee.getSSSNumber(),
            employee.getPhilHealthNumber(),
            employee.getTINNumber(),
            employee.getPagIBIGNumber(),
            employee.getStatus(),
            employee.getPosition(),
            employee.getImmediateSupervisor(),
            employee.getBasicSalary(),
            employee.getRiceSubsidy(),
            employee.getPhoneAllowance(),
            employee.getClothingAllowance(),
            employee.getGrossSemiMonthlyRate(),
            employee.getHourlyRate()

        });
    }

    // Shows Info
    private void showInfo(String message) {

        JOptionPane.showMessageDialog(
                this,
                message,
                "Information",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // Shows Error
    private void showError(String message) {

        JOptionPane.showMessageDialog(
                this,
                message,
                "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}
