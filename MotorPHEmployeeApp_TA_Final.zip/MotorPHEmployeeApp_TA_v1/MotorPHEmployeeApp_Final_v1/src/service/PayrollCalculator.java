/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
 /*package service;

import java.time.Duration;
import java.time.LocalTime;
import java.time.Month;
import java.time.YearMonth;
import java.util.List;
import model.Attendance;
import model.Employee;
import model.PayrollResult;*/
// UPDATED CODE
package service;

import java.time.Duration;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import model.Attendance;
import model.Employee;
import model.PayrollRecord;
import model.PayrollSummary;

/**
 *
 * @author Home
 */
//UPDATED PAYROLL CALCULATOR 
public class PayrollCalculator {

    public static final String FIRST_HALF = "1 - 15";
    //public static final String SECOND_HALF  = "16 - End of Month";
    //public static final String WHOLE_MONTH = "Whole Month";
    
    public static final String SECOND_HALF = "16 - 30/31";
    public static final String WHOLE_MONTH = "1 - 30/31";

    private static final int MAX_WORKING_MINS = 540;
    private static final int LUNCH_BREAK_MINS = 60;
    private static final int MINS_PER_HOUR = 60;

    // Compute Working Hours 
    public double computeHoursWorked(
            LocalTime login,
            LocalTime logout
    ) {

        LocalTime startTime = LocalTime.of(8, 0);

        LocalTime graceLimit = LocalTime.of(8, 10);

        LocalTime endTime = LocalTime.of(17, 0);

        // Remove overtime
        if (logout.isAfter(endTime)) {
            logout = endTime;
        }

        // Apply grace period
        if (!login.isAfter(graceLimit)) {
            login = startTime;
        }

        long lateMinutes
                = Math.max(
                        0,
                        Duration.between(
                                startTime,
                                login
                        ).toMinutes()
                );

        long minutesWorked
                = Math.min(
                        Duration.between(
                                login,
                                logout
                        ).toMinutes(),
                        MAX_WORKING_MINS - lateMinutes
                );

        // Lunch break deduction
        if (minutesWorked > 60) {

            minutesWorked -= LUNCH_BREAK_MINS;

        } else {

            minutesWorked = 0;

        }

        return (double) minutesWorked / MINS_PER_HOUR;

    }

    // Compute One Employee Payroll
    public PayrollRecord computePayroll(
            Employee employee,
            List<Attendance> attendanceList,
            int year,
            int month,
            String coverage
    ) {

        double totalHours = 0;

        for (Attendance attendance : attendanceList) {

            if (matchesAttendance(
                    attendance,
                    employee,
                    year,
                    month,
                    coverage
            )) {

                totalHours += computeHoursWorked(
                        attendance.getLogIn(),
                        attendance.getLogOut()
                );

            }
        }

        if (totalHours == 0) {

            return null;

        }

        double grossPay
                = totalHours * employee.getHourlyRate();

        // Deductions
        double sss
                = Deductions.computeSSSContribution(
                        grossPay
                );

        double philHealth
                = Deductions.computePhilHealthContribution(
                        grossPay
                );

        double pagIBIG
                = Deductions.computePagIBIGContribution(
                        grossPay
                );

        double withholdingTax
                = 0;

        // Semi-monthly split
        if (coverage.equals(FIRST_HALF)
                || coverage.equals(SECOND_HALF)) {

            sss /= 2;

            philHealth /= 2;

            pagIBIG /= 2;

        }

        double totalDeductions
                = Deductions.computeTotalDeductions(
                        sss,
                        pagIBIG,
                        philHealth
                );

        double taxableIncome
                = Deductions.computeTaxableIncome(
                        grossPay,
                        totalDeductions
                );

        withholdingTax
                = Deductions.computeWithholdingTax(
                        taxableIncome
                );

        if (coverage.equals(FIRST_HALF)
                || coverage.equals(SECOND_HALF)) {

            withholdingTax /= 2;

        }

        double netPay
                = grossPay
                - totalDeductions
                - withholdingTax;

        return new PayrollRecord(
                employee.getEmpNo(),
                year,
                month,
                coverage,
                totalHours,
                grossPay,
                sss,
                philHealth,
                pagIBIG,
                withholdingTax,
                totalDeductions,
                netPay
        );

    }

    // Compute All Employees
    public List<PayrollRecord> computeAllPayroll(
            List<Employee> employees,
            List<Attendance> attendanceList,
            int year,
            int month,
            String coverage
    ) {

        List<PayrollRecord> payrollList
                = new ArrayList<>();

        for (Employee employee : employees) {

            PayrollRecord record
                    = computePayroll(
                            employee,
                            attendanceList,
                            year,
                            month,
                            coverage
                    );

            if (record != null) {

                payrollList.add(record);

            }

        }

        return payrollList;

    }

    // Attendance Filter 
    private boolean matchesAttendance(
            Attendance attendance,
            Employee employee,
            int year,
            int month,
            String coverage
    ) {

        if (attendance.getEmpNo()
                != employee.getEmpNo()) {

            return false;

        }

        if (attendance.getDate()
                .getYear() != year) {

            return false;

        }

        if (attendance.getDate()
                .getMonthValue() != month) {

            return false;

        }

        int day
                = attendance.getDate()
                        .getDayOfMonth();

        if (coverage.equals(FIRST_HALF)) {

            return day <= 15;

        }

        if (coverage.equals(SECOND_HALF)) {

            return day > 15;

        }

        return true;

    }

    // Display Pay Covearge 
    public String buildCoverageText(
            int year,
            int month,
            String coverage
    ) {

        Month monthName
                = Month.of(month);

        if (coverage.equals(FIRST_HALF)) {

            return monthName
                    + " 1 - 15";

        }

        if (coverage.equals(SECOND_HALF)) {

            return monthName
                    + " 16 - "
                    + YearMonth.of(
                            year,
                            month
                    ).lengthOfMonth();

        }

        return monthName
                + " 1 - "
                + YearMonth.of(
                        year,
                        month
                ).lengthOfMonth();

    }
    
    // Calculates Totals For Payroll Summary
    public PayrollSummary calculateTotals(
            List<PayrollRecord> payrollRecords
    ) {

        if (payrollRecords == null
                || payrollRecords.isEmpty()) {

            return new PayrollSummary(
                    0,
                    0,
                    0,
                    0
            );

        }

        int employeeCount = 0;

        double totalGross = 0;

        double totalDeduction = 0;

        double totalNet = 0;

        for (PayrollRecord record
                : payrollRecords) {

            employeeCount++;

            totalGross
                    += record.getGrossPay();

            totalDeduction
                    += record.getTotalDeductions()
                    + record.getWithholdingTax();

            totalNet
                    += record.getNetPay();

        }

        double averageNet
                = totalNet / employeeCount;

        return new PayrollSummary(
                employeeCount,
                totalGross,
                totalDeduction,
                averageNet
        );

    }

}
