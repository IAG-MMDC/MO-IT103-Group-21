/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.time.format.DateTimeFormatter;

import model.Employee;
import model.PayrollRecord;
import model.PayrollSummary;

/**
 *
 * @author Home
 */
public class Formatter {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    // Employee Profile Format
    public static String formatEmployeeProfile(Employee employee) {

        return String.format(
                """
                ========================================
                        EMPLOYEE PROFILE
                ========================================

                Personal Information
                ----------------------------------------
                %-25s %s
                %-25s %s
                %-25s %s
                %-25s %s

                ----------------------------------------
                Contact Information
                ----------------------------------------
                %-25s %s
                %-25s %s

                ----------------------------------------
                Government Information
                ----------------------------------------
                %-25s %s
                %-25s %s
                %-25s %s
                %-25s %s

                ----------------------------------------
                Employment Information
                ----------------------------------------
                %-25s %s
                %-25s %s
                %-25s %s

                ----------------------------------------
                Salary Information
                ----------------------------------------
                %-25s ₱%,.2f
                %-25s ₱%,.2f
                %-25s ₱%,.2f
                %-25s ₱%,.2f
                %-25s ₱%,.2f
                %-25s ₱%,.2f

                ========================================
                ========================================
                """,
                "Employee ID:",
                employee.getEmpNo(),
                "Last Name:",
                employee.getLastName(),
                "First Name:",
                employee.getFirstName(),
                "Birthday:",
                employee.getBirthday()
                        .format(DATE_FORMAT),
                "Address:",
                employee.getAddress(),
                "Phone #:",
                employee.getPhoneNumber(),
                "SSS #:",
                employee.getSSSNumber(),
                "PhilHealth #:",
                employee.getPhilHealthNumber(),
                "TIN #:",
                employee.getTINNumber(),
                "PagIBIG #:",
                employee.getPagIBIGNumber(),
                "Status:",
                employee.getStatus(),
                "Position:",
                employee.getPosition(),
                "Immediate Supervisor:",
                employee.getImmediateSupervisor(),
                "Basic Salary:",
                (double) employee.getBasicSalary(),
                "Rice Subsidy:",
                (double) employee.getRiceSubsidy(),
                "Phone Allowance:",
                (double) employee.getPhoneAllowance(),
                "Clothing Allowance:",
                (double) employee.getClothingAllowance(),
                "Gross Semi-Monthly Rate:",
                (double) employee.getGrossSemiMonthlyRate(),
                "Hourly Rate:",
                employee.getHourlyRate()
        );

    }

    // Payslip Format
    public static String formatPayslip(
            Employee employee,
            PayrollRecord payroll
    ) {

        return String.format("""
                ========================================
                            MOTORPH PAYSLIP
                ========================================

                Employee Information
                ----------------------------------------
                %-25s : %d
                %-25s : %s %s
                %-25s : %s

                Payroll Period
                ----------------------------------------
                %-25s : %s
                %-25s : %.2f hours

                Salary Information
                ----------------------------------------
                %-25s : ₱%,.2f
                %-25s : ₱%,.2f

                Deductions
                ----------------------------------------
                %-25s : ₱%,.2f
                %-25s : ₱%,.2f
                %-25s : ₱%,.2f
                %-25s : ₱%,.2f
                %-25s : ₱%,.2f

                ----------------------------------------
                %-25s : ₱%,.2f
                ========================================
                ========================================
                        """,
                // Employee Information
                "Employee ID",
                employee.getEmpNo(),
                "Employee Name",
                employee.getFirstName(),
                employee.getLastName(),
                "Position",
                employee.getPosition(),
                // Payroll Period
                "Pay Coverage",
                payroll.getPayCoverage(),
                "Hours Worked",
                payroll.getHoursWorked(),
                // Salary Information
                "Gross Salary",
                payroll.getGrossPay(),
                "Hourly Rate",
                employee.getHourlyRate(),
                // Deductions
                "SSS",
                payroll.getSSS(),
                "PhilHealth",
                payroll.getPhilHealth(),
                "Pag-IBIG",
                payroll.getPagIBIG(),
                "Withholding Tax",
                payroll.getWithholdingTax(),
                "Total Deductions",
                payroll.getTotalDeductions(),
                // Net Pay
                "NET SALARY",
                payroll.getNetPay()
        );
    }

    // Payroll Summary Format
    public static String formatSummary(
            int year,
            String month,
            String coverage,
            PayrollSummary summary
    ) {

        return String.format(
                """
                ========================================
                     MOTORPH PAYROLL SUMMARY
                ========================================

                Payroll Period
                ----------------------------------------
                %-20s : %d
                %-20s : %s
                %-20s : %s


                Payroll Statistics
                ----------------------------------------
                %-20s : %d
                %-20s : ₱%,.2f
                %-20s : ₱%,.2f
                %-20s : ₱%,.2f


                ========================================
                Generated by MotorPH Employee App
                ========================================
                """,
                "Year",
                year,
                "Month",
                month,
                "Pay Period",
                coverage,
                "Total Employees",
                summary.getTotalEmployees(),
                "Total Gross Pay",
                summary.getTotalGrossPay(),
                "Total Deductions",
                summary.getTotalDeductions(),
                "Average Net Pay",
                summary.getAverageNetPay()
        );

    }
}
