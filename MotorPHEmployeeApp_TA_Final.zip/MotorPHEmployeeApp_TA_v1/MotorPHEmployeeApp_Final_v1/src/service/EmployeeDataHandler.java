/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import model.Employee;

/**
 *
 * @author Home
 */
public class EmployeeDataHandler {

    private static final String EMP_CSV = "resources/MotorPH_Employee Data - Employee Details.csv";
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("MM/dd/yyyy"); 

    // Read Employees
    public static List<Employee> readEmployees() {

        List<Employee> employees = new ArrayList<>();

        // Read Employee Details CSV
        try (BufferedReader br = new BufferedReader(new FileReader(EMP_CSV))) {

            br.readLine();
            String currentLine;

            while ((currentLine = br.readLine()) != null) {
                if (currentLine.trim().isEmpty()) {
                    continue;
                }

                List<String> data = CSVParser.parseCSVLine(currentLine);

                if (data.size() != 19) {
                    throw new IllegalArgumentException("Invalid employee record: expected 19 columns but got " + data.size());
                }

                int empNo = Integer.parseInt(data.get(0));
                String lastName = data.get(1);
                String firstName = data.get(2);
                LocalDate birthday = LocalDate.parse(data.get(3), DATE_FORMAT);
                String address = data.get(4);
                String phoneNumber = data.get(5);
                String sssNumber = data.get(6);
                String philhealthNumber = data.get(7);
                String tinNumber = data.get(8);
                String pagibigNumber = data.get(9);
                String status = data.get(10);
                String position = data.get(11);
                String immediateSupervisor = data.get(12);
                int basicSalary = CSVParser.parseIntValue(data.get(13));
                int riceSubsidy = CSVParser.parseIntValue(data.get(14));
                int phoneAllowance = CSVParser.parseIntValue(data.get(15));
                int clothingAllowance = CSVParser.parseIntValue(data.get(16));
                int grossSemiMonthlyRate = CSVParser.parseIntValue(data.get(17));
                double hourlyRate = Double.parseDouble(data.get(18));

                Employee employee
                        = new Employee(empNo,
                                lastName,
                                firstName,
                                birthday,
                                address,
                                phoneNumber,
                                sssNumber,
                                philhealthNumber,
                                tinNumber,
                                pagibigNumber,
                                status,
                                position,
                                immediateSupervisor,
                                basicSalary,
                                riceSubsidy,
                                phoneAllowance,
                                clothingAllowance,
                                grossSemiMonthlyRate,
                                hourlyRate);

                // Stores Employee Details CSV
                employees.add(employee);
            }
        } catch (DateTimeParseException e) {
            System.out.println("Error reading date.");
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(
                    "Unable to read employee file.",
                    e);
        }

        return employees;
    }

    // Overwrite Employees
    public static void writeEmployees(List<Employee> employees) {

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(EMP_CSV))) {

            bw.write("Employee #,"
                    + "Last Name,"
                    + "First Name,"
                    + "Birthday, "
                    + "Address,"
                    + "Phone Number,"
                    + "SSS #,"
                    + "PhilHealth #,"
                    + "TIN #,"
                    + "PagIBIG #,"
                    + "Status,"
                    + "Position,"
                    + "Immediate Supervisor,"
                    + "Basic Salary,"
                    + "Rice Subsidy,"
                    + "Phone Allowance,"
                    + "Clothing Allowance,"
                    + "Gross Semi-Monthly Rate,"
                    + "Hourly Rate");

            bw.newLine();

            for (Employee e : employees) {

                bw.write(e.getEmpNo() + ","
                        + e.getLastName() + ","
                        + e.getFirstName() + ","
                        + e.getBirthday().format(DATE_FORMAT) + ","
                        + CSVParser.csv(e.getAddress()) + ","
                        + e.getPhoneNumber() + ","
                        + e.getSSSNumber() + ","
                        + e.getPhilHealthNumber() + ","
                        + e.getTINNumber() + ","
                        + e.getPagIBIGNumber() + ","
                        + e.getStatus() + ","
                        + e.getPosition() + ","
                        + CSVParser.csv(e.getImmediateSupervisor()) + ","
                        + e.getBasicSalary() + ","
                        + e.getRiceSubsidy() + ","
                        + e.getPhoneAllowance() + ","
                        + e.getClothingAllowance() + ","
                        + e.getGrossSemiMonthlyRate() + ","
                        + e.getHourlyRate()
                );
                bw.newLine();
            }
        } catch (IOException e) {

            e.printStackTrace();

            throw new RuntimeException(
                    "Unable to write employee file.",
                    e);
        }
    }

    // Add Employee
    public static void addEmployee(Employee newEmployee) {

        List<Employee> employees = readEmployees();

        // added
        validateEmployee(newEmployee);
        checkDuplicateEmployee(newEmployee.getEmpNo(), employees);

        employees.add(newEmployee);
        writeEmployees(employees);
    }

    // Update Employee
    public static void updateEmployee(Employee updatedEmployee) {

        List<Employee> employees = readEmployees();

        validateEmployee(updatedEmployee);

        boolean found = false;

        for (Employee e : employees) {

            if (e.getEmpNo() == updatedEmployee.getEmpNo()) {

                found = true;

                e.setLastName(updatedEmployee.getLastName());
                e.setFirstName(updatedEmployee.getFirstName());
                e.setBirthday(updatedEmployee.getBirthday());
                e.setAddress(updatedEmployee.getAddress());
                e.setPhoneNumber(updatedEmployee.getPhoneNumber());
                e.setSSSNumber(updatedEmployee.getSSSNumber());
                e.setPhilHealthNumber(updatedEmployee.getPhilHealthNumber());
                e.setTINNumber(updatedEmployee.getTINNumber());
                e.setPagIBIGNumber(updatedEmployee.getPagIBIGNumber());
                e.setStatus(updatedEmployee.getStatus());
                e.setPosition(updatedEmployee.getPosition());
                e.setImmediateSupervisor(updatedEmployee.getImmediateSupervisor());
                e.setBasicSalary(updatedEmployee.getBasicSalary());
                e.setRiceSubsidy(updatedEmployee.getRiceSubsidy());
                e.setPhoneAllowance(updatedEmployee.getPhoneAllowance());
                e.setClothingAllowance(updatedEmployee.getClothingAllowance());
                e.setGrossSemiMonthlyRate(updatedEmployee.getGrossSemiMonthlyRate());
                e.setHourlyRate(updatedEmployee.getHourlyRate());

                break;
            }
        }

        if (!found) {
            throw new IllegalArgumentException(
                    "Employee Number " + updatedEmployee.getEmpNo() + " does not exist.");
        }

        writeEmployees(employees);
    }

    // Delete Employee
    public static void deleteEmployee(int empNo) {

        List<Employee> employees = readEmployees();

        boolean removed = employees.removeIf(e -> e.getEmpNo() == empNo);

        if (!removed) {
            throw new IllegalArgumentException("Employee Number " + empNo + " does not exist.");
        }

        writeEmployees(employees);
    }

    // Find Employee 
    public static Employee findEmpNo(int empNo) {

        List<Employee> employees = readEmployees();

        for (Employee e : employees) {
            if (e.getEmpNo() == empNo) {
                return e;
            }
        }

        return null;
    }

    // Validate Employee
    private static void validateEmployee(Employee employee) {

        if (employee.getEmpNo() <= 0) {
            throw new IllegalArgumentException(
                    "Employee Number must be greater than zero.");
        }

        if (employee.getLastName().isBlank()) {
            throw new IllegalArgumentException(
                    "Last Name is required.");
        }

        if (employee.getFirstName().isBlank()) {
            throw new IllegalArgumentException(
                    "First Name is required.");
        }

        if (employee.getBirthday() == null) {
            throw new IllegalArgumentException(
                    "Birthday is required.");
        }

        if (employee.getBasicSalary() < 0) {
            throw new IllegalArgumentException(
                    "Basic Salary cannot be negative.");
        }

        if (employee.getHourlyRate() < 0) {
            throw new IllegalArgumentException(
                    "Hourly Rate cannot be negative.");
        }
    }

// Check Duplicate Employee
    private static void checkDuplicateEmployee(
            int empNo,
            List<Employee> employees) {

        for (Employee e : employees) {

            if (e.getEmpNo() == empNo) {

                throw new IllegalArgumentException(
                        "Employee Number " + empNo + " already exists.");
            }
        }
    }
}
