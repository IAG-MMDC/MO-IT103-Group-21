/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.util.ArrayList;
import java.util.List;

import model.PayrollRecord;
import model.PayrollSummary;

// UPDATED CODE
public class PayrollDataHandler {
    
    // CSV Locations
    private static final String PAYROLL_CSV = "resources/Payroll_Record.csv";
    
    private static final String SUMMARY_CSV
            = "resources/Payroll_Summary.csv";
    
    // Payroll Record CSV Header
    private static final String PAYROLL_HEADER
            = "Employee No,"
            + "Year,"
            + "Month,"
            + "Pay Coverage,"
            + "Hours Worked,"
            + "Gross Pay,"
            + "SSS,"
            + "PhilHealth,"
            + "PagIBIG,"
            + "Withholding Tax,"
            + "Total Deductions,"
            + "Net Pay";

    // Payroll Summary Header
    private static final String SUMMARY_HEADER
            = "Year,"
            + "Month,"
            + "Pay Coverage,"
            + "Total Employees,"
            + "Total Gross Pay,"
            + "Total Deductions,"
            + "Average Net Pay";

    // Creates Payroll Record CSV File
    private static void createPayrollFile() throws IOException {

        File file = new File(PAYROLL_CSV);

        if (!file.exists()) {

            file.createNewFile();

            try (
                    BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {

                writer.write(PAYROLL_HEADER);

                writer.newLine();
            }
        }
    }

    // Reads Payroll Records
    public static List<PayrollRecord> readPayrollRecords() throws IOException {

        List<PayrollRecord> payrollList = new ArrayList<>();

        File file = new File(PAYROLL_CSV);

        if (!file.exists()) {
            return payrollList;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            // Skip header
            reader.readLine();

            String line;

            while ((line = reader.readLine()) != null) {

                if (line.trim().isEmpty()) {
                    continue;
                }

                List<String> data = CSVParser.parseCSVLine(line);

                PayrollRecord record = new PayrollRecord(
                        Integer.parseInt(data.get(0)),
                        Integer.parseInt(data.get(1)),
                        Integer.parseInt(data.get(2)),
                        data.get(3),
                        Double.parseDouble(data.get(4)),
                        Double.parseDouble(data.get(5)),
                        Double.parseDouble(data.get(6)),
                        Double.parseDouble(data.get(7)),
                        Double.parseDouble(data.get(8)),
                        Double.parseDouble(data.get(9)),
                        Double.parseDouble(data.get(10)),
                        Double.parseDouble(data.get(11))
                );

                payrollList.add(record);
            }
        }

        return payrollList;
    }

    // Save Payroll
    public static void savePayroll(
            List<PayrollRecord> newRecords
    )
            throws IOException {

        if (newRecords == null
                || newRecords.isEmpty()) {

            return;

        }

        createPayrollFile();

        List<PayrollRecord> existingRecords
                = readPayrollRecords();

        PayrollRecord first
                = newRecords.get(0);

        /*
            Remove previous payroll
            with same:
            
            Year
            Month
            Coverage
            
            Then replace
         */
        existingRecords.removeIf(record
                -> record.getYear()
                == first.getYear()
                && record.getMonth()
                == first.getMonth()
                && record.getPayCoverage()
                        .equals(
                                first.getPayCoverage()
                        )
        );

        existingRecords.addAll(newRecords);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PAYROLL_CSV))) {

            // Writes header
            writer.write(PAYROLL_HEADER);
            writer.newLine();

            for (PayrollRecord record : existingRecords) {

                writer.write(payrollToCSV(record));

                writer.newLine();
            }
        }
    }

    // Find Payroll Records
    public static List<PayrollRecord> findPayrollRecords(
            int year,
            int month,
            String coverage
    ) throws IOException {

        List<PayrollRecord> result = new ArrayList<>();

        for (PayrollRecord record : readPayrollRecords()) {

            if (record.getYear()
                    == year
                    && record.getMonth()
                    == month
                    && record.getPayCoverage()
                            .equals(coverage)) {

                result.add(record);

            }

        }

        return result;
    }

    // Check Duplicate Payroll
    public static boolean payrollExists(
            int year,
            int month,
            String coverage
    )
            throws IOException {

        return !findPayrollRecords(
                year,
                month,
                coverage
        ).isEmpty();

    }

    // Converts Payroll Record To CSV
    private static String payrollToCSV(
            PayrollRecord record
    ) {

        return record.getEmpNo()
                + ","
                + record.getYear()
                + ","
                + record.getMonth()
                + ","
                + record.getPayCoverage()
                + ","
                + record.getHoursWorked()
                + ","
                + record.getGrossPay()
                + ","
                + record.getSSS()
                + ","
                + record.getPhilHealth()
                + ","
                + record.getPagIBIG()
                + ","
                + record.getWithholdingTax()
                + ","
                + record.getTotalDeductions()
                + ","
                + record.getNetPay();

    }
    
    // =====================================
    // Payroll Summary Section
    // =====================================
    
    // Create Payroll Summary CSV File
    private static void createSummaryFile()
            throws IOException {

        File file
                = new File(SUMMARY_CSV);

        // Creates file if it does not exist
        if (!file.exists()) {

            file.createNewFile();

        }
        // Adds header if file is empty
        if (file.length() == 0) {

            try (
                    BufferedWriter writer
                    = new BufferedWriter(
                            new FileWriter(file)
                    )) {

                writer.write(SUMMARY_HEADER);

                writer.newLine();

            }

        }

    }
    // Save Payroll Summary
    public static boolean saveSummary(
            int year,
            int month,
            String coverage,
            PayrollSummary summary
    )
            throws IOException {

        createSummaryFile();

        // Prevent duplicate summary
        if (summaryExists(
                year,
                month,
                coverage
        )) {

            return false;

        }

        try (
                BufferedWriter writer
                = new BufferedWriter(
                        new FileWriter(
                                SUMMARY_CSV,
                                true
                        )
                )) {

            writer.write(
                    year + ","
                    + month + ","
                    + coverage + ","
                    + summary.getTotalEmployees() + ","
                    + summary.getTotalGrossPay() + ","
                    + summary.getTotalDeductions() + ","
                    + summary.getAverageNetPay()
            );

            writer.newLine();

        }
        return true;
    }
    
    // Checks Duplicate Payroll Summary Duplicate
    public static boolean summaryExists(
            int year,
            int month,
            String coverage
    )
            throws IOException {

        File file
                = new File(SUMMARY_CSV);

        if (!file.exists()) {

            return false;

        }

        try (
                BufferedReader reader
                = new BufferedReader(
                        new FileReader(file)
                )) {

            // Skip header row
            reader.readLine();

            String line;

            while ((line = reader.readLine())
                    != null) {

                if (line.trim().isEmpty()) {

                    continue;

                }

                String[] data
                        = line.split(",");

                int savedYear
                        = Integer.parseInt(data[0]);

                int savedMonth
                        = Integer.parseInt(data[1]);

                String savedCoverage
                        = data[2];

                if (savedYear == year
                        && savedMonth == month
                        && savedCoverage.equals(coverage)) {

                    return true;

                }
            }
        }

        return false;
    }
}
